﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using MidtermProject.Utilities;


//line 34 Creating the registration stored procedure
//line 39 Creating the login stored procedure 
//line 44 Creating the is email exists in database stored procedure
//line 49 Creating the password reset stored procedure
//line 54 Creating the Login information table
//line 72 Creating the Orders table
//line 93 Creating the Soldiers table
//line 115 Generating 50 random rows into both tables


//**Please use update-database in Package Manager Console before build/debug**  => // If after update-database all Hebrew letters are shown as question marks:
                                                                                  // Comment the loop in line:115-129, and *uncomment* the loop in 133-147, This will generate the table rows in English instead of Hebrew
                                                                                 // Make sure to delete DbSoldiers in SSMS before running update-database again
                                                                                // (You can run both loops, but if you have question marks as Hebrew then it will be mixed with the English rows..)

                                                                             /// If after update-database you get the following error: 'Year, Month and Day parameters describe an un-representable DateTime.' please go to the following link for fix (https://github.com/LearAdini/Midterm-Project/blob/main/README.md#Fix-DateTime-Error).
                                                                            /// If after update-database you get the following error: '6.0.0 is not compatible with net5.0-windows7.0' please go to the following link for fix and download from "Run desktop apps" and choose the currect download for your system specification(https://dotnet.microsoft.com/download/dotnet/5.0/runtime?utm_source=getdotnetcore&utm_medium=referral).

namespace MidtermProject.Migrations
{
    public partial class MainMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

            RandomColumns randomColumns = new RandomColumns();


            migrationBuilder.Sql(
                "CREATE OR ALTER PROCEDURE sp_RegisterUserHash(@userName varchar(20),@password varchar(100),@salt uniqueidentifier,@email varchar(100))" +
                " AS BEGIN INSERT INTO dbo.LoginInfoHashed (UserName,Password,salt,Email,createdOn)" +
                " VALUES (@userName,HASHBYTES('MD5', @password + cast(@salt as nvarchar(36))),@salt,@email,GETDATE()) END");

            migrationBuilder.Sql(
                "CREATE OR ALTER PROCEDURE sp_LoginUserHash(@userName varchar(20),@password varchar(100))" +
                " AS BEGIN SELECT COUNT(*) FROM [DbSoldiers].[dbo].[LoginInfoHashed]" +
                " WHERE UserName = @userName AND Password = HASHBYTES('MD5', @password + cast(salt as nvarchar(36))) END");

            migrationBuilder.Sql(
                "CREATE OR ALTER PROCEDURE sp_VerifyEmail(@email varchar(100))" +
                " AS BEGIN SELECT COUNT(*) FROM [DbSoldiers].[dbo].[LoginInfoHashed]" +
                " WHERE Email = @email END");

            migrationBuilder.Sql(
                "CREATE OR ALTER PROCEDURE sp_ResetPassword(@password varchar(100),@email varchar(100))" +
                " AS BEGIN UPDATE LoginInfoHashed set Password = HASHBYTES('MD5', @password + cast(salt as nvarchar(36))) WHERE Email=@email END");


            migrationBuilder.CreateTable(
               name: "LoginInfoHashed",
               columns: table => new
               {
                   UserId = table.Column<int>(type: "int", nullable: false)
                                 .Annotation("SqlServer:Identity", "1, 1"),
                   Email = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false),
                   UserName = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: false),
                   password = table.Column<byte[]>(type: "binary(64)", maxLength: 100, nullable: false),
                   salt = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                   createdOn = table.Column<DateTime>(type: "datetime", nullable: false, defaultValue: new DateTime())
               },
               constraints: table =>
               {
                   table.PrimaryKey("PK_LoginInfoHashed", x => x.UserId);
               });


            migrationBuilder.CreateTable(
                name: "OrderInfo",
                columns: table => new
                {
                    מספר__הזמנה = table.Column<int>(type: "int", nullable: false)
                                        .Annotation("SqlServer:Identity", "1, 1"),
                    מי__הזמין = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    סוג = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    מוצר = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: false),
                    כמות__ביחידות = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    מחיר__ליחידה = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    סהכ__מחיר = table.Column<int>(type: "int", nullable: false),
                    תאריך__הזמנה = table.Column<string>(type: "varchar(100)", nullable: false),
                    האם__שולם = table.Column<string>(type: "varchar(2)", maxLength: 2, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderInfo", x => x.מספר__הזמנה);
                });


            migrationBuilder.CreateTable(
                name: "SoldierInfo",
                columns: table => new
                {
                    תז = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: false),
                    שם__פרטי = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    שם__משפחה = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    עיר__מגורים = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    כתובת__בית = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    תפקיד = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: true),
                    דרגה = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    קבע = table.Column<string>(type: "varchar(2)", maxLength: 2, nullable: true),
                    תאריך__גיוס = table.Column<string>(type: "varchar(100)", nullable: false),
                    תאריך__לידה = table.Column<string>(type: "varchar(100)", nullable: false),
                    מין = table.Column<string>(type: "varchar(1)", maxLength: 1, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SoldierInfo", x => x.תז);
                });

            #region Comment this for loop(line:115-129) if hebrew rows are shown as question marks, and uncomment the next loop(line:133-147)    
            for (int i = 0; i < 50; i++)  /// creating 50 rows into soldier & order tables and an inner join that tells who ordered what by its תז
            {
                System.Threading.Thread.Sleep(50);
                migrationBuilder.Sql($"INSERT INTO dbo.SoldierInfo VALUES('{randomColumns.RandomId()}','{randomColumns.RandomFirstName()}'" +
                    $",'{randomColumns.RandomLastName()}','{randomColumns.RandomCity()}','{randomColumns.RandomStreet()}'" +
                    $",'{randomColumns.RandomRole()}','{randomColumns.RandomRank()}','{randomColumns.RandomKeva()}'" +
                    $",'{randomColumns.RandomGiusDay()}','{randomColumns.RandomBirthDay()}','{randomColumns.RandomGender()}');");


                migrationBuilder.Sql($"INSERT INTO dbo.OrderInfo VALUES('{randomColumns._Global}','{randomColumns.RandomOrderType()}'" +
                    $",'{randomColumns.RandomOrderProduct()}',{randomColumns.RandomOrderQuantity()}" +
                    $",{randomColumns.RandomOrderPricePerUnit()},{randomColumns.TotalOrderPrice()}" +
                    $",'{randomColumns.RandomOrderDate()}','כן');" +
                    $" SELECT o.מי__הזמין from OrderInfo o INNER JOIN SoldierInfo s on s.תז = o.מי__הזמין");
            }
            #endregion

            #region Uncomment this for loop(line:133-147) if hebrew rows are shown as question marks 
            /* for (int i = 0; i < 50; i++)
             {
                 System.Threading.Thread.Sleep(50);
                 migrationBuilder.Sql($"INSERT INTO dbo.SoldierInfo VALUES('{randomColumns.RandomId()}','{randomColumns.RandomFirstName_en()}'" +
                     $",'{randomColumns.RandomLastName_en()}','{randomColumns.RandomCity_en()}','{randomColumns.RandomStreet_en()}'" +
                     $",'{randomColumns.RandomRole_en()}','{randomColumns.RandomRank_en()}','{randomColumns.RandomKeva_en()}'" +
                     $",'{randomColumns.RandomGiusDay()}','{randomColumns.RandomBirthDay()}','{randomColumns.RandomGender_en()}');");


                 migrationBuilder.Sql($"INSERT INTO dbo.OrderInfo VALUES('{randomColumns._Global}','{randomColumns.RandomOrderType_en()}'" +
                     $",'{randomColumns.RandomOrderProduct_en()}',{randomColumns.RandomOrderQuantity_en()}" +
                     $",{randomColumns.RandomOrderPricePerUnit_en()},{randomColumns.TotalOrderPrice()}" +
                     $",'{randomColumns.RandomOrderDate()}','Y');" +
                     $" SELECT o.מי__הזמין from OrderInfo o INNER JOIN SoldierInfo s on s.תז = o.מי__הזמין");
             }*/
            #endregion
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LoginInfoHashed");

            migrationBuilder.DropTable(
                name: "OrderInfo");

            migrationBuilder.DropTable(
                name: "SoldierInfo");

            migrationBuilder.Sql("drop procedure sp_RegisterUserHash");

            migrationBuilder.Sql("drop procedure sp_LoginUserHash");

            migrationBuilder.Sql("drop procedure sp_VerifyEmail");

            migrationBuilder.Sql("drop procedure sp_ResetPasssword");

        }
    }
}
