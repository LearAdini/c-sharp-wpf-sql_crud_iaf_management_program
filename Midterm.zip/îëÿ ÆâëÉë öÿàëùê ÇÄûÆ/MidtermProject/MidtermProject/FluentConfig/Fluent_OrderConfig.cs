﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MidtermProject.Models;

namespace MidtermProject.FluentConfig
{
   public class Fluent_OrderConfig : IEntityTypeConfiguration<OrderInfo>
    {         
        public void Configure(EntityTypeBuilder<OrderInfo> modelBuilder)
        {
            modelBuilder.HasKey(p => p.מספר__הזמנה);          
            modelBuilder.Property(p => p.מי__הזמין).HasMaxLength(450);  
            modelBuilder.Property(p => p.סוג).IsRequired().HasMaxLength(15);  
            modelBuilder.Property(p => p.מוצר).IsRequired().HasMaxLength(25);  
            modelBuilder.Property(p => p.כמות__ביחידות).IsRequired();
            modelBuilder.Property(p => p.מחיר__ליחידה).IsRequired();
            modelBuilder.Property(p => p.סהכ__מחיר);
            modelBuilder.Property(p => p.תאריך__הזמנה);
            modelBuilder.Property(p => p.האם__שולם).HasMaxLength(2);
        }
    }
}



