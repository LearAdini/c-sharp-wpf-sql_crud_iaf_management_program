﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using MidtermProject.Models;
namespace MidtermProject.FluentConfig
{
    public class Fluent_LoginInfoHashedConfig : IEntityTypeConfiguration<LoginInfoHashed>
    {
        public void Configure(EntityTypeBuilder<LoginInfoHashed> modelBuilder)
        {
            modelBuilder.HasKey(p => p.UserId);//Makes UserId as PrimaryKey
            modelBuilder.Property(p => p.UserName).HasMaxLength(20).IsRequired(); // Makes UserName as not nullable and maximum length of 20
            modelBuilder.Property(p => p.Email).HasMaxLength(100).IsRequired();
            modelBuilder.Property(p => p.password).HasMaxLength(100).IsRequired();
            modelBuilder.Property(p => p.salt);
            modelBuilder.Property(p => p.createdOn).HasDefaultValue(DateTime.Now);
        }
    }
}




