﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MidtermProject.Models;

namespace MidtermProject.FluentConfig
{
   public class Fluent_SoldierConfig : IEntityTypeConfiguration<SoldierInfo>
    {
        public void Configure(EntityTypeBuilder<SoldierInfo> modelBuilder)
        { 
            modelBuilder.HasKey(p => p.תז);
            modelBuilder.Property(p => p.שם__פרטי).IsRequired().HasMaxLength(20);
            modelBuilder.Property(p => p.שם__משפחה).IsRequired().HasMaxLength(30);
            modelBuilder.Property(p => p.עיר__מגורים).HasMaxLength(20);
            modelBuilder.Property(p => p.כתובת__בית).HasMaxLength(50);
            modelBuilder.Property(p => p.תפקיד).HasMaxLength(25);
            modelBuilder.Property(p => p.דרגה).HasMaxLength(10);
            modelBuilder.Property(p => p.קבע).HasMaxLength(2);
            modelBuilder.Property(p => p.תאריך__גיוס).IsRequired();
            modelBuilder.Property(p => p.תאריך__לידה).IsRequired();
            modelBuilder.Property(p => p.מין).HasMaxLength(1);
        }
    }
}

