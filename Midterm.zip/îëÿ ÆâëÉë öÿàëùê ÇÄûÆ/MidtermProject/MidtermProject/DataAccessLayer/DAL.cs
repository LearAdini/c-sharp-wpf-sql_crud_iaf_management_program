﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using MidtermProject.Pages;
using MidtermProject.Models;
using System.Windows.Controls;
using System.Windows.Media;
using MidtermProject.Utilities;



namespace MidtermProject.DataAccessLayer
{
    public class DAL
    {
        private static SqlConnection sqlCon = new SqlConnection(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=DbSoldiers;Integrated Security=SSPI;");
        public SqlConnection _SqlCon { get { return sqlCon; } set { sqlCon = value; } }

        private SoldiersPage PageSoldier = new();
        private OrdersPage PageOrders = new();
        public AircraftsPage PageAirCrafts = new();
        public TyasotPage PageTyasot = new();

        public RegisterPage PageRegister = new();

        public InfoPage PageInfo = new();
        public GuestInfoPage PageInfoGuest = new();
        private GuestOrderPage PageGuestOrder = new();

        public static IpCheck ip = new();
        public ContentControl ccmw = new();
        public SolidColorBrush customColor = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#545d6a"));
        public string lear = "lear";

        //public SoldiersDBContext _db = new SoldiersDBContext();

        public async Task<SoldierInfo> AddSoldierAsync()
        {
            try
            {
                using (var dbContext = new SoldiersDBContext())
                {

                    var count = dbContext.SoldierInfo.Where(x => x.תז == PageSoldier.TextBoxTaz.Text).Count();

                    if (count == 1)
                    {
                        MessageBox.Show("! חייל עם אותה תעודת הזהות כבר קיים במערכת");
                    }
                    else
                    {
                        var newSoldier = new SoldierInfo
                        {
                            תז = PageSoldier.TextBoxTaz.Text,
                            שם__פרטי = PageSoldier.TextBox1.Text,
                            שם__משפחה = PageSoldier.TextBox2.Text,
                            עיר__מגורים = PageSoldier.TextBox3.Text,
                            כתובת__בית = PageSoldier.TextBox4.Text,
                            תפקיד = PageSoldier.ComboBox1.Text,
                            דרגה = PageSoldier.ComboBox2.Text,
                            קבע = PageSoldier.ComboBox3.Text,
                            מין = PageSoldier.ComboBox4.Text,
                            תאריך__גיוס = PageSoldier.GiusDate.SelectedDate.ToString(),
                            תאריך__לידה = PageSoldier.BrithDateHayal.SelectedDate.ToString()
                        };

                        await dbContext.AddAsync(newSoldier);
                        await dbContext.SaveChangesAsync();
                        MessageBox.Show("! התווסף בהצלחה");
                        return newSoldier;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                await CheckConnectionStatusAsync(); // Close connection function 
                ccmw.Content = await SqlCommandSoldiersPageAsync("SELECT * FROM SoldierInfo ORDER BY עיר__מגורים", "SoldierInfo");  // "refresh" DataGridView after a new soldier is added
            }

            return default;


            #region using(var dbContext = new SoldiersDBContext()) ,The same operations could occour with _db property but I would NOT want to use _db prop, because SoldiersDBContext is meant to be used per request and should not be instantiated as global property of the context class to use..

            /*
           try
            {              
                var newSoldier = new SoldierInfo
                {
                    תז = PageSoldier.TextBoxTaz.Text,
                    שם__פרטי = PageSoldier.TextBox1.Text,
                    שם__משפחה = PageSoldier.TextBox2.Text,
                    עיר__מגורים = PageSoldier.TextBox3.Text,
                    כתובת__בית = PageSoldier.TextBox4.Text,
                    תפקיד = PageSoldier.ComboBox1.Text,
                    דרגה = PageSoldier.ComboBox2.Text,
                    קבע = PageSoldier.ComboBox3.Text,
                    מין = PageSoldier.ComboBox4.Text,
                    תאריך__גיוס = PageSoldier.GiusDate.SelectedDate.ToString(),
                    תאריך__לידה = PageSoldier.BrithDateHayal.SelectedDate.ToString()
                };

                await _db.AddAsync(newSoldier); *

                await _db.SaveChangesAsync(); *


                MessageBox.Show("! התווסף בהצלחה");
                return newSoldier;
            }

            catch (Exception ex)
            {
                MessageBox.Show("תעודת הזהות קיימת במערכת \n" + ex.Message);
            }
            finally
            {
                await CheckConnectionStatusAsync(); // Close connection function 
                ccmw.Content = await SqlCommandSoldiersPageAsync("SELECT * FROM SoldierInfo", "SoldierInfo");  // "refresh" DataGridView after a new soldier is added
            }

            return default;
            */
            #endregion

            #region ADO.NET - StoredProcedure option
            /*        
       SqlCommand sqlcmd = new()
       {
           Connection = dal.SqlCon,
           CommandText = "spAddSoldier", // removed this stored procedure becasue its not beeing used in the project, this is just an example
           CommandType = CommandType.StoredProcedure
       };

       sqlcmd.Parameters.Add("@שם_פרטי", SqlDbType.NVarChar).Value = TextBox1.Text;
       sqlcmd.Parameters.Add("@שם_משפחה", SqlDbType.NVarChar).Value = TextBox2.Text;
       sqlcmd.Parameters.Add("@עיר_מגורים", SqlDbType.NVarChar).Value = TextBox3.Text;
       sqlcmd.Parameters.Add("@כתובת_בית", SqlDbType.NVarChar).Value = TextBox4.Text;
       sqlcmd.Parameters.Add("@תפקיד", SqlDbType.NVarChar).Value = ComboBox1.Text;
       sqlcmd.Parameters.Add("@דרגה", SqlDbType.NVarChar).Value = ComboBox2.Text;
       sqlcmd.Parameters.Add("@קבע", SqlDbType.NChar).Value = ComboBox3.Text;
       sqlcmd.Parameters.Add("@תאריך_גיוס", SqlDbType.DateTime).Value = GiusDate.SelectedDate;
       sqlcmd.Parameters.Add("@תאריך_לידה", SqlDbType.DateTime).Value = BrithDateHayal.SelectedDate;
       sqlcmd.Parameters.Add("@מין", SqlDbType.NChar).Value = ComboBox4.Text;
       */
            #endregion
        }

        public async Task<OrderInfo> AddOrderAsync()
        {
            int a, b, sum;

            a = int.Parse(PageOrders.TextBoxQuantity.Text);
            b = int.Parse(PageOrders.TextBoxPrice.Text);

            sum = a * b; // Calculate the total price of the ordered item by (Quantity * Price) = database gets סהכ__מחיר

            try
            {
                using (var dbContext = new SoldiersDBContext())
                {
                    var newOrder = new OrderInfo
                    {
                        מי__הזמין = $"{ip._IP}",
                        סוג = PageOrders.ComboBoxType.Text,
                        מוצר = PageOrders.TextBoxProduct.Text,
                        כמות__ביחידות = PageOrders.TextBoxQuantity.Text,
                        מחיר__ליחידה = PageOrders.TextBoxPrice.Text,
                        האם__שולם = "כן",
                        סהכ__מחיר = sum,
                        תאריך__הזמנה = DateTime.Now.ToString()
                    };
                    await dbContext.AddAsync(newOrder);
                    await dbContext.SaveChangesAsync();

                    MessageBox.Show("! התווסף בהצלחה");
                    return newOrder;
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                await CheckConnectionStatusAsync();
                ccmw.Content = await SqlCommandOrdersPageAsync("SELECT * FROM OrderInfo", "OrderInfo");  // "refresh" DataGridView after a new order is added
            }

            return default;

            #region ADO.NET - StoredProcedure option
            /*        
       SqlCommand sqlcmd = new()
       {
           Connection = dal.SqlCon,
           CommandText = "spAddOrder", // removed this stored procedure becasue its not beeing used in the project, this is just an example
           CommandType = CommandType.StoredProcedure
       };

       sqlcmd.Parameters.Add("@מי__הזמין", SqlDbType.NVarChar).Value = ip._IP;
       sqlcmd.Parameters.Add("@סוג", SqlDbType.NVarChar).Value = PageOrders.ComboBoxType.Text;
       sqlcmd.Parameters.Add("@מוצר", SqlDbType.NVarChar).Value = PageOrders.TextBoxProduct.Text;
       sqlcmd.Parameters.Add("@כמות__ביחידות", SqlDbType.NVarChar).Value = PageOrders.TextBoxQuantity.Text;
       sqlcmd.Parameters.Add("@מחיר__ליחידה", SqlDbType.NVarChar).Value = PageOrders.TextBoxPrice.Text;
       sqlcmd.Parameters.Add("@האם__שולם", SqlDbType.NVarChar).Value = "כן";
       sqlcmd.Parameters.Add("@סהכ__מחיר", SqlDbType.NChar).Value = sum;
       sqlcmd.Parameters.Add("@תאריך__הזמנה", SqlDbType.DateTime).Value = DateTime.Now.ToString();

       */
            #endregion
        }


        public async Task<OrderInfo> AddGuestOrderAsync()
        {
            int a, b, sum;

            a = int.Parse(PageGuestOrder.TextBoxQuantity.Text);
            b = int.Parse(PageGuestOrder.TextBoxPrice.Text);

            sum = a * b;

            try
            {
                using (var dbContext = new SoldiersDBContext())
                {
                    var newGuestOrder = new OrderInfo
                    {
                        מי__הזמין = $"{LoginPage._userName}",
                        סוג = PageGuestOrder.ComboBoxType.Text,
                        מוצר = PageGuestOrder.TextBoxProduct.Text,
                        כמות__ביחידות = PageGuestOrder.TextBoxQuantity.Text,
                        מחיר__ליחידה = PageGuestOrder.TextBoxPrice.Text,
                        האם__שולם = "כן",
                        סהכ__מחיר = sum,
                        תאריך__הזמנה = DateTime.Now.ToString()
                    };
                    await dbContext.AddAsync(newGuestOrder);
                    await dbContext.SaveChangesAsync();

                    MessageBox.Show("! התווסף בהצלחה");
                    return newGuestOrder;
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                await CheckConnectionStatusAsync();
                ccmw.Content = await SqlCommandGuestOrdersPageAsync($"SELECT * FROM OrderInfo WHERE מי__הזמין = '{LoginPage._userName}'", "OrderInfo"); // "refresh" DataGridView after a new guest order is added
            }

            return default;
        }

        public async Task UpdateSoldiersAsync()
        {
            try
            {
                using (var dbContext = new SoldiersDBContext())
                {
                    var count = dbContext.SoldierInfo.Where(x => x.שם__פרטי == PageSoldier.TextBox6.Text && x.שם__משפחה == PageSoldier.TextBox7.Text && x.תז == PageSoldier.TextBoxTazOld.Text).Count();

                    if (count == 1)
                    {
                        var soldier = dbContext.SoldierInfo.FirstOrDefault(x => x.שם__פרטי == PageSoldier.TextBox6.Text && x.שם__משפחה == PageSoldier.TextBox7.Text && x.תז == PageSoldier.TextBoxTazOld.Text);

                        soldier.שם__פרטי = PageSoldier.TextBox1_Copy.Text;
                        soldier.שם__משפחה = PageSoldier.TextBox2_Copy.Text;
                        soldier.עיר__מגורים = PageSoldier.TextBox3_Copy.Text;
                        soldier.כתובת__בית = PageSoldier.TextBox4_Copy.Text;
                        soldier.תפקיד = PageSoldier.ComboBox1_Copy.Text;
                        soldier.דרגה = PageSoldier.ComboBox2_Copy.Text;
                        soldier.קבע = PageSoldier.ComboBox3_Copy.Text;
                        soldier.תאריך__גיוס = PageSoldier.GiusDate_Copy.Text;
                        soldier.תאריך__לידה = PageSoldier.BrithDateHayal_Copy.Text;
                        soldier.מין = PageSoldier.ComboBox4_Copy.Text;

                        dbContext.Update(soldier);
                        await dbContext.SaveChangesAsync();
                        MessageBox.Show("! עודכן בהצלחה");
                    }

                    if (count == 0)
                    {
                        MessageBox.Show("! חייל זה אינו קיים במערכת " + "\n" + "אנא וודא כי השדות נכונות");
                    }
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                await CheckConnectionStatusAsync();
                ccmw.Content = await SqlCommandSoldiersPageAsync("SELECT * FROM SoldierInfo ORDER BY עיר__מגורים", "SoldierInfo");
            }


            #region ADO.Net Option
            /*
            try
            {
                SqlCommand sqlcmd = new()
                {
                    Connection = _SqlCon,
                    CommandText = $"UPDATE SoldierInfo SET שם__פרטי = '{PageSoldier.TextBox1_Copy.Text}' , שם__משפחה = '{PageSoldier.TextBox2_Copy.Text}' ," +
                    $" עיר__מגורים = '{PageSoldier.TextBox3_Copy.Text}' , כתובת__בית = '{PageSoldier.TextBox4_Copy.Text}' , תפקיד = '{PageSoldier.ComboBox1_Copy.Text}' ," +
                    $" דרגה = '{PageSoldier.ComboBox2_Copy.Text}' , קבע = '{PageSoldier.ComboBox3_Copy.Text}' , תאריך__גיוס = '{PageSoldier.GiusDate_Copy.Text} '," +
                    $" תאריך__לידה = '{PageSoldier.BrithDateHayal_Copy.Text}' , מין = '{PageSoldier.ComboBox4_Copy.Text}'" +
                    $" WHERE שם__פרטי = '{PageSoldier.TextBox6.Text}' and שם__משפחה = '{PageSoldier.TextBox7.Text}' and תז = '{PageSoldier.TextBoxTazOld.Text}'"
                };

                SqlCommand checkExist = new()
                {
                    Connection = _SqlCon,
                    CommandText = $"SELECT COUNT(*) FROM SoldierInfo WHERE שם__פרטי = '{PageSoldier.TextBox6.Text}' and שם__משפחה = '{PageSoldier.TextBox7.Text}' and תז = '{PageSoldier.TextBoxTazOld.Text}'"
                };
                await _SqlCon.OpenAsync();
                int count = Convert.ToInt32(await checkExist.ExecuteScalarAsync());

                if (count == 1)
                {

                    await sqlcmd.ExecuteNonQueryAsync();
                    MessageBox.Show("! עודכן בהצלחה");
                }

                if (count == 0)
                {
                    MessageBox.Show("! חייל זה אינו קיים במערכת " + "\n" + "אנא וודא כי השדות נכונות");
                }

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                await CheckConnectionStatusAsync();
                ccmw.Content = await SqlCommandSoldiersPageAsync("SELECT * FROM SoldierInfo", "SoldierInfo");
            }
            */
            #endregion
        }

        public async Task UpdateOrderAsync()
        {
            try
            {
                int a, b, sum;

                a = int.Parse(PageOrders.TextBoxQuantity_Copy.Text);
                b = int.Parse(PageOrders.TextBoxPrice_Copy.Text);
                sum = a * b;

                using (var dbContext = new SoldiersDBContext())
                {
                    var count = dbContext.OrderInfo.Where(x => x.מספר__הזמנה == int.Parse(PageOrders.TextBoxOrderNumber.Text)).Count();

                    if (count == 1)
                    {
                        var order = dbContext.OrderInfo.SingleOrDefault(s => s.מספר__הזמנה == int.Parse(PageOrders.TextBoxOrderNumber.Text));

                        order.סוג = PageOrders.ComboBoxType_Copy.Text;
                        order.מוצר = PageOrders.TextBoxProduct_Copy.Text;
                        order.כמות__ביחידות = PageOrders.TextBoxQuantity_Copy.Text;
                        order.מחיר__ליחידה = PageOrders.TextBoxPrice_Copy.Text;
                        order.סהכ__מחיר = sum;

                        dbContext.Update(order);
                        await dbContext.SaveChangesAsync();
                        MessageBox.Show("! עודכן בהצלחה");
                    }

                    if (count == 0)
                    {
                        MessageBox.Show("! מספר הזמנה זה אינו קיים מערכת");
                    }
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                await CheckConnectionStatusAsync();
                ccmw.Content = await SqlCommandOrdersPageAsync("SELECT * FROM OrderInfo", "OrderInfo");
            }


            #region ADO.Net Option
            /*
            try
            {
                await _SqlCon.OpenAsync();

                int a, b, sum;

                a = int.Parse(PageOrders.TextBoxQuantity_Copy.Text);
                b = int.Parse(PageOrders.TextBoxPrice_Copy.Text);

                sum = a * b;


                SqlCommand sqlcmd = new()
                {
                    Connection = _SqlCon,
                    CommandText = $"UPDATE OrderInfo SET סוג = '{PageOrders.ComboBoxType_Copy.Text}' , מוצר = '{PageOrders.TextBoxProduct_Copy.Text}' , כמות__ביחידות = '{PageOrders.TextBoxQuantity_Copy.Text}' , מחיר__ליחידה = '{PageOrders.TextBoxPrice_Copy.Text}' , סהכ__מחיר = {sum} WHERE מספר__הזמנה = {PageOrders.TextBoxOrderNumber.Text}"
                };

                SqlCommand checkExist = new()
                {
                    Connection = _SqlCon,
                    CommandText = $"SELECT COUNT(*) FROM OrderInfo WHERE מספר__הזמנה = '{PageOrders.TextBoxOrderNumber.Text}'"
                };


                int count = Convert.ToInt32(await checkExist.ExecuteScalarAsync());

                if (count == 1)
                {
                    await sqlcmd.ExecuteNonQueryAsync();
                    MessageBox.Show("! עודכן בהצלחה");
                }

                if (count == 0)
                {
                    MessageBox.Show("! מספר הזמנה זה אינו קיים מערכת");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                await CheckConnectionStatusAsync();
                ccmw.Content = await SqlCommandOrdersPageAsync("SELECT * FROM OrderInfo", "OrderInfo");
            }*/
            #endregion
        }

        public async Task DeleteSoldierAsync()
        {
            try
            {
                using (var dbContext = new SoldiersDBContext())
                {
                    var count = dbContext.SoldierInfo.Where(x => x.שם__פרטי == PageSoldier.TextBoxNameDel.Text && x.שם__משפחה == PageSoldier.TextBoxLastNameDel.Text && x.תז == PageSoldier.TextBoxTazDel.Text).Count();

                    if (count == 1)
                    {
                        var taz = dbContext.SoldierInfo.SingleOrDefault(x => x.תז == PageSoldier.TextBoxTazDel.Text && x.שם__פרטי == PageSoldier.TextBoxNameDel.Text && x.שם__משפחה == PageSoldier.TextBoxLastNameDel.Text);

                        dbContext.Remove(taz);
                        await dbContext.SaveChangesAsync();

                        MessageBox.Show($" {PageSoldier.TextBoxNameDel.Text} {PageSoldier.TextBoxLastNameDel.Text}\n נמחק בהצלחה ");
                    }
                    if (count == 0)
                    {
                        MessageBox.Show("! פרטי חייל זה אינו קיים במערכת " + "\n" + "אנא וודא כי השדות נכונות");
                    }
                };

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                await CheckConnectionStatusAsync();
                ccmw.Content = await SqlCommandSoldiersPageAsync("SELECT * FROM SoldierInfo ORDER BY עיר__מגורים", "SoldierInfo");
            }

            #region ADO.Net - check exists only
            /*
            try
            {
                await _SqlCon.OpenAsync();

                SqlCommand checkExist = new()
                {
                    Connection = _SqlCon,
                    CommandText = $"SELECT COUNT(*) FROM SoldierInfo WHERE תז = {PageSoldier.TextBoxTazDel.Text} and שם__פרטי = '{PageSoldier.TextBoxNameDel.Text}' and שם__משפחה = '{PageSoldier.TextBoxLastNameDel.Text}'"
                };

                int count = Convert.ToInt32(await checkExist.ExecuteScalarAsync());

                if (count == 1)
                {
                    using (var dbContext = new SoldiersDBContext())
                    {

                        var taz = dbContext.SoldierInfo.SingleOrDefault(x => x.תז == PageSoldier.TextBoxTazDel.Text && x.שם__פרטי == PageSoldier.TextBoxNameDel.Text && x.שם__משפחה == PageSoldier.TextBoxLastNameDel.Text);

                        dbContext.Remove(taz);
                        await dbContext.SaveChangesAsync();

                        MessageBox.Show($" {PageSoldier.TextBoxNameDel.Text} {PageSoldier.TextBoxLastNameDel.Text}\n נמחק בהצלחה ");
                    }
                }

                if (count == 0)
                {
                    MessageBox.Show("! פרטי חייל זה אינו קיים במערכת " + "\n" + "אנא וודא כי השדות נכונות");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                await CheckConnectionStatusAsync();
                ccmw.Content = await SqlCommandSoldiersPageAsync("SELECT * FROM SoldierInfo", "SoldierInfo");
            }
            */
            #endregion
        }

        public async Task DeleteOrderAsync()
        {
            try
            {
                using (var dbContext = new SoldiersDBContext())
                {
                    var count = dbContext.OrderInfo.Where(x => x.מספר__הזמנה == int.Parse(PageOrders.TextBoxOrderNumberDel.Text)).Count();

                    if (count == 1)
                    {
                        var order = dbContext.OrderInfo.SingleOrDefault(x => x.מספר__הזמנה == int.Parse(PageOrders.TextBoxOrderNumberDel.Text));

                        dbContext.Remove(order);
                        await dbContext.SaveChangesAsync();

                        MessageBox.Show($"{PageOrders.TextBoxOrderNumberDel.Text}\n נמחק בהצלחה");
                    }

                    if (count == 0)
                    {
                        MessageBox.Show("! מספר הזמנה זה אינו קיים מערכת");
                    }
                };
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                await CheckConnectionStatusAsync();
                ccmw.Content = await SqlCommandOrdersPageAsync("SELECT * FROM OrderInfo", "OrderInfo");
            }

            #region ADO.Net - check exists only
            /*
              try
            {
                await _SqlCon.OpenAsync();

                SqlCommand checkExist = new()
                {
                    Connection = _SqlCon,
                    CommandText = $"SELECT COUNT(*) FROM OrderInfo WHERE מספר__הזמנה = '{PageOrders.TextBoxOrderNumberDel.Text}'"
                };

                int count = Convert.ToInt32(await checkExist.ExecuteScalarAsync());

                if (count == 1)
                {
                    using (var dbContext = new SoldiersDBContext())
                    {
                        string text = PageOrders.TextBoxOrderNumberDel.Text;
                        int value = int.Parse(text);

                        var order = dbContext.OrderInfo.SingleOrDefault(x => x.מספר__הזמנה == value);

                        dbContext.Remove(order);
                        await dbContext.SaveChangesAsync();

                        MessageBox.Show($"{PageOrders.TextBoxOrderNumberDel.Text}\n נמחק בהצלחה");
                    }
                }

                if (count == 0)
                {
                    MessageBox.Show("! מספר הזמנה זה אינו קיים מערכת");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                await CheckConnectionStatusAsync();
                ccmw.Content = await SqlCommandOrdersPageAsync("SELECT * FROM OrderInfo", "OrderInfo");
            }
             */
            #endregion
        }

        public async Task<SoldiersPage> SqlCommandSoldiersPageAsync(string Command, string dataTable)
        {
            try
            {
                await sqlCon.OpenAsync();

                SqlCommand sqlCommand = new SqlCommand(Command, sqlCon);

                await sqlCommand.ExecuteNonQueryAsync();

                SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);

                DataTable dt = new DataTable(dataTable);

                dataAdapter.Fill(dt);

                PageSoldier.SoldierGridView.ItemsSource = dt.DefaultView;

                return PageSoldier;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                await CheckConnectionStatusAsync();
            }

            return default;
        }

        public async Task<OrdersPage> SqlCommandOrdersPageAsync(string Command, string dataTable)
        {
            try
            {
                await sqlCon.OpenAsync();

                SqlCommand sqlCommand = new SqlCommand(Command, sqlCon);

                await sqlCommand.ExecuteNonQueryAsync();

                SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);

                DataTable dt = new DataTable(dataTable);

                dataAdapter.Fill(dt);

                PageOrders.OrdersGridView.ItemsSource = dt.DefaultView;

                return PageOrders;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                await CheckConnectionStatusAsync();
            }

            return default;
        }

        public async Task<GuestOrderPage> SqlCommandGuestOrdersPageAsync(string Command, string dataTable)
        {
            try
            {
                await sqlCon.OpenAsync();

                SqlCommand sqlCommand = new SqlCommand(Command, sqlCon);

                await sqlCommand.ExecuteNonQueryAsync();

                SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlCommand);

                DataTable dt = new DataTable(dataTable);

                dataAdapter.Fill(dt);

                PageGuestOrder.GuestOrdersGridView.ItemsSource = dt.DefaultView;

                return PageGuestOrder;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                await CheckConnectionStatusAsync();
            }

            return default;
        }


        public async Task CheckConnectionStatusAsync()
        {
            if (sqlCon.State == ConnectionState.Open)
            {
                await sqlCon.CloseAsync();
            }
        }

        public async Task OpenBrowserAsync(string url)
        {
            await Task.Run(() =>
            {
                var process = new System.Diagnostics.ProcessStartInfo(url)
                {
                    UseShellExecute = true,
                    Verb = "open"
                };

                try
                {
                    System.Diagnostics.Process.Start(process);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Cannot open window  \n Error:" + ex.Message);
                }
            });

        }

    }
}

