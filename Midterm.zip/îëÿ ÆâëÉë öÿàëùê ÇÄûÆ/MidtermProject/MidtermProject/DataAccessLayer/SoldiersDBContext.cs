﻿using Microsoft.EntityFrameworkCore;
using MidtermProject.Models;
using MidtermProject.FluentConfig;

namespace MidtermProject.DataAccessLayer
{
    public class SoldiersDBContext : DbContext
    {
        public DbSet<SoldierInfo> SoldierInfo { get; set; }
        public DbSet<OrderInfo> OrderInfo { get; set; }
        public DbSet<LoginInfoHashed> LoginInfoHashed { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"Server=localhost\SQLEXPRESS;Database=DbSoldiers;Trusted_Connection=True;MultipleActiveResultSets=True;Integrated Security=SSPI;");
                optionsBuilder.EnableSensitiveDataLogging();
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new Fluent_LoginInfoHashedConfig());

            modelBuilder.ApplyConfiguration(new Fluent_SoldierConfig());

            modelBuilder.ApplyConfiguration(new Fluent_OrderConfig());         
        }

    }
}




