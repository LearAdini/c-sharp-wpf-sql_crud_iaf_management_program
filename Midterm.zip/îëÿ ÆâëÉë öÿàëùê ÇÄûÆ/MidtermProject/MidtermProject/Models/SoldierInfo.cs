﻿namespace MidtermProject.Models
{
    public class SoldierInfo
    {
        public string תז { get; set; }
        public string שם__פרטי { get; set; }
        public string שם__משפחה { get; set; }
        public string עיר__מגורים { get; set; }
        public string כתובת__בית { get; set; }
        public string תפקיד { get; set; }
        public string דרגה { get; set; }
        public string קבע { get; set; }
        public string תאריך__גיוס { get; set; }
        public string תאריך__לידה { get; set; }
        public string מין { get; set; }  
    }
}


