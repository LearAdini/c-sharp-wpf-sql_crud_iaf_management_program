﻿namespace MidtermProject.Models
{
    public class OrderInfo
    {
        public int מספר__הזמנה { get; set; }
        public string מי__הזמין { get; set; }
        public string סוג { get; set; }
        public string מוצר { get; set; }
        public string כמות__ביחידות { get; set; }
        public string מחיר__ליחידה { get; set; }
        public int סהכ__מחיר { get; set; }
        public string תאריך__הזמנה { get; set; }
        public string האם__שולם { get; set; }
    }
}


