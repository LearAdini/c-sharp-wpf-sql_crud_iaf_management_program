﻿using System;

namespace MidtermProject.Models
{
   public class LoginInfoHashed
    {
        public int UserId { get; set; }
        public string Email { get; set; }
        public string UserName { get; set; }
        public byte[] password { get; set; }
        public Guid salt { get; set; }
        public DateTime createdOn { get; set; }
    }
}