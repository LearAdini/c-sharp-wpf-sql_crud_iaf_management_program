﻿using MidtermProject.DataAccessLayer;
using MidtermProject.Utilities.StateMachines;
using System;
using System.Windows;

namespace MidtermProject.Pages
{
    public partial class GuestPage : Window
    {
        private _StateContext stateContext = new(new LoginMachine());
        private DAL dal = new DAL();
        static GuestOrderPage guestOrders = new();


        public GuestPage()
        {
            InitializeComponent();
            Main.Content = dal.PageInfoGuest; // After guest user is logged in, guest info page is loaded
        }

        private void btn_AircraftsClick(object sender, RoutedEventArgs e)
        {
            Main.Content = dal.PageAirCrafts;
        }

        private void btn_TyasotClick(object sender, RoutedEventArgs e)
        {
            Main.Content = dal.PageTyasot;
        }

        private void btn_InfoClick(object sender, RoutedEventArgs e)
        {
            Main.Content = dal.PageInfoGuest;
        }

        private async void btn_OrdersClick(object sender, RoutedEventArgs e)
        {
            await guestOrders.GuestOrdersWindowLoad(Main);
        }

        private async void btn_GitClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://learadini.github.io/Interface/");
        }

        private async void GuestWindow_Closed(object sender, EventArgs e)
        {
            await dal.CheckConnectionStatusAsync();
            this.Close();
            LoginPage lp = new();
            lp.Show();
        }

        private void GuestWindow_Activated(object sender, EventArgs e)
        {
            stateContext.LoginSuccess();
        }
       
    }
}
