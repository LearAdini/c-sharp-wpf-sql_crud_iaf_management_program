﻿using System.Windows.Controls;


namespace MidtermProject.Pages
{
    public partial class InfoPage : Page
    {
        public InfoPage()
        {
            InitializeComponent();
        }
    }
}
