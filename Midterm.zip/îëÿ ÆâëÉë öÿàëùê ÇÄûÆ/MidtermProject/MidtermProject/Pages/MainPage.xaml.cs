﻿using MidtermProject.DataAccessLayer;
using MidtermProject.Utilities.StateMachines;
using System;
using System.Windows;

namespace MidtermProject.Pages
{
    public partial class MainPage : Window
    {
        private _StateContext stateContext = new(new LoginMachine());
        private DAL dal = new();

        static SoldiersPage soldiers = new();

        static OrdersPage orders = new();
    
        public MainPage()
        {
            InitializeComponent();
            Main.Content = dal.PageInfo; // After admin is logged in, info page is loaded
        }


        private async void btn_SoldiersClick(object sender, RoutedEventArgs e)
        {
            await soldiers.SoldierWindowLoad(Main);
        }

        private async void btn_OrdersClick(object sender, RoutedEventArgs e)
        {
            await orders.OrdersWindowLoad(Main);
        }

        private void btn_AircraftsClick(object sender, RoutedEventArgs e)
        {           
            Main.Content = dal.PageAirCrafts;
        }

        private void btn_TyasotClick(object sender, RoutedEventArgs e)
        {
            Main.Content = dal.PageTyasot;
        }

        private void btn_InfoClick(object sender, RoutedEventArgs e)
        {
            Main.Content = dal.PageInfo;
        }

        private async void btn_GitClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://learadini.github.io/Interface/");
        }

        private async void MainWindow_Close(object sender, EventArgs e)
        {
            await dal.CheckConnectionStatusAsync();
            this.Close();
            LoginPage lp = new();
            lp.Show();
        }

        private void MainWindow_Activated(object sender, EventArgs e)
        {
            stateContext.LoginSuccess();
        }
    }
}
