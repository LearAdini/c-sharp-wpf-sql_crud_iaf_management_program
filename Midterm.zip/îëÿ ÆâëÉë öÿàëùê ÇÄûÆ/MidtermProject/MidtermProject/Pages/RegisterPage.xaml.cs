﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Data.SqlClient;
using System.Data;
using MidtermProject.DataAccessLayer;

namespace MidtermProject.Pages
{
    public partial class RegisterPage : Window
    {
        private static DAL dal = new DAL();

        private static System.Text.RegularExpressions.Regex _regexPass;
        private static System.Text.RegularExpressions.Regex _regexUser;


        public RegisterPage()
        {
            InitializeComponent();
            username.CharacterCasing = System.Windows.Controls.CharacterCasing.Lower;
            email.CharacterCasing = System.Windows.Controls.CharacterCasing.Lower;
        }


        private async void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!_regexPass.IsMatch(password.Password))
                {
                    MessageBox.Show("! על הסיסמה להכיל 8 תווים עם אות אחת גדולה ואות אחת קטנה לפחות");
                }
                else if (!_regexUser.IsMatch(username.Text))
                {
                    MessageBox.Show("! על שם המשתמש להכיל 4 תווים עם מספר אחד ואות אחת לפחות");
                }

                else if (username.Text.Length >= 20)
                {
                    MessageBox.Show("! שם משתמש עד 20 תווים בלבד");
                }
                else if (password.Password.Length >= 100)
                {
                    MessageBox.Show("! סיסמה עד 100 תווים בלבד");
                }

                else if (username.Text == string.Empty || password.Password == string.Empty || email.Text == string.Empty)
                {
                    MessageBox.Show("אנא וואדא כי מלאת את כל השדות");
                }
                else if (passwordConfirm.Password == string.Empty)
                {
                    MessageBox.Show("אנא וואדא כי מלאת אימות סיסמה");
                }
                else if (password.Password != passwordConfirm.Password)
                {
                    MessageBox.Show("אנא וודא כי הסיסמאות תואמאות");
                }
                else if (!email.Text.Contains("@") || !email.Text.Contains(".com") && !email.Text.Contains(".co.il") && !email.Text.Contains(".gov") && !email.Text.Contains(".net") && !email.Text.Contains(".org") && !email.Text.Contains(".edu") && !email.Text.Contains(".biz") && !email.Text.Contains(".ca") && !email.Text.Contains(".xyz") && !email.Text.Contains(".vn") && !email.Text.Contains(".info"))
                {
                    MessageBox.Show("אנא וודא כי הזנת כתובת אימייל נכונה");
                }

                else if (password.Password == passwordConfirm.Password && username.Text != string.Empty)
                {
                    await UserCheckAsync();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                await dal.CheckConnectionStatusAsync();
            }
        }


        #region UserCheckAsync:
        /// using ADO.NET stored procedure, the stored procedure is generated via raw sql code in the migration file..
        /// UserCheckAsync : Search if the user with the given username or email already exists in the database,
        /// if theres no registered username with the given value in username.Text or email does not exist in the database, count equal to 0.
        /// So count = 0 will create a new user and will convert the given password to HASHBYTES,
        /// and casted into a uniqueidentifier data type called salt. else means the username or email already exist in the database(count=1)
        #endregion
        public async Task UserCheckAsync()
        {
            try
            {
                using (var dbContext = new SoldiersDBContext())
                {
                    var count = dbContext.LoginInfoHashed.Where(x => x.UserName == username.Text || x.Email == email.Text).Count();

                    #region ADO.NET - count command
                    /*
                    SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM LoginInfoHashed WHERE UserName=@userName or Email=@email", dal._SqlCon);

                    cmd.Parameters.AddWithValue("@userName", username.Text);

                    cmd.Parameters.AddWithValue("@email", email.Text);

                    await dal._SqlCon.OpenAsync();

                    int count = Convert.ToInt32(await cmd.ExecuteScalarAsync());
                    */

                    #endregion

                    if (count == 0)
                    {
                        await dal._SqlCon.OpenAsync();
                        SqlCommand sqlCmd = new SqlCommand("sp_RegisterUserHash", dal._SqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;


                        sqlCmd.Parameters.AddWithValue("@userName", username.Text);

                        sqlCmd.Parameters.AddWithValue("@email", email.Text);

                        sqlCmd.Parameters.AddWithValue("@password", password.Password);

                        sqlCmd.Parameters.AddWithValue("@salt", Guid.NewGuid());


                        await sqlCmd.ExecuteNonQueryAsync();

                        MessageBox.Show("התווסף בהצלחה");

                        this.Hide();

                        LoginPage lp = new();
                        lp.Show();
                    }

                    else // count == 1, user or email already exists in the database
                    {
                        MessageBox.Show("שם משתמש / אימייל כבר קיים במערכת");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                await dal.CheckConnectionStatusAsync();
                password.Clear();
                passwordConfirm.Clear();
            }
        }


        private async void btnBack_Click(object sender, RoutedEventArgs e)
        {
            await dal.CheckConnectionStatusAsync();
            this.Hide();
            LoginPage lp = new();
            lp.Show();
        }

        private void RegMouseIn(object sender, MouseEventArgs e)
        {
            btnRegister.Background = Brushes.DarkOrange;
            btnRegister.Foreground = dal.customColor;
        }

        private void RegMouseLeave(object sender, MouseEventArgs e)
        {
            btnRegister.Background = dal.customColor;
            btnRegister.Foreground = Brushes.White;
        }

        private async void WindowRegisterPage_Closed(object sender, EventArgs e)
        {
            await dal.CheckConnectionStatusAsync();
            App.Current.Shutdown();
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }


        private void WindowRegisterPage_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (MessageBox.Show("              ? האם ברצונך לצאת", "                                          יציאה", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                e.Cancel = false;
            else
                e.Cancel = true;
        }

        private void LowerCasesValidation_usernameBox(object sender, TextCompositionEventArgs e)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(@"(?=.*?[a-z]+)(?=.*?[0-9.-]+).{4,}");// this regex will make user input only lower cases and numbers accepted and at the minimum length of 4 characters, at least 3 letters/numbers with 1 letter/number to be accepted as a username, making it to be at least of 4 characters.| correct: hey1, he11, h111, h11h, h1hh, h1h1| wrong: 1111, hhhh |
            e.Handled = regex.IsMatch(e.Text);
            _regexUser = regex;
        }

        private void PasswordValidation_passwordBox(object sender, TextCompositionEventArgs e)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(@"(?=.*?[a-z])(?=.*?[A-Z]).{8,}");// (?=.*?[a-z]) checks if theres at least one/any lower case character,
            e.Handled = regex.IsMatch(e.Text);                                                                                      // (?=.*?[A-Z]) checks if theres at least one/any upper case character,
            _regexPass = regex;                                                                                                         // .{8,}    checks if any character is at least 8 times.| correct: Hey01234,llllFFFF, lGlGlGlG | wrong: HEY01234, heybyego , HEYBYEGO| .{8,} Makes the password input length to be at least one lower case, one upper case and at the least length of 8 character long.
        }
    }
}