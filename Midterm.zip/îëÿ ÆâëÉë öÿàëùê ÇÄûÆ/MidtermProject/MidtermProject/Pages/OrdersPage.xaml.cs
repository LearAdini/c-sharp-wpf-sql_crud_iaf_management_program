﻿using MidtermProject.DataAccessLayer;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace MidtermProject.Pages
{
    public partial class OrdersPage : Page
    {
        private static DAL dal = new DAL();

        static MainPage mw = new MainPage();

        public OrdersPage()
        {
            InitializeComponent();
        }

        private async void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ComboBoxType.Text == string.Empty || TextBoxProduct.Text == string.Empty || TextBoxQuantity.Text == string.Empty || TextBoxPrice.Text == string.Empty)
                {
                    MessageBox.Show("! אנא מלא את כל השדות ");
                }               
                else
                {
                    await dal.AddOrderAsync();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);
            }
        }

        private async void ButtonUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (TextBoxOrderNumber.Text == string.Empty || ComboBoxType_Copy.Text == string.Empty || TextBoxProduct_Copy.Text == string.Empty || TextBoxQuantity_Copy.Text == string.Empty || TextBoxPrice_Copy.Text == string.Empty)
                {
                    MessageBox.Show("! אנא מלא את כל השדות לעידכון");
                }
                else
                {
                    await dal.UpdateOrderAsync();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);
            }
        }

        private async void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (TextBoxOrderNumberDel.Text == string.Empty)
                {
                    MessageBox.Show("אנא כתוב את מספר ההזמנה");
                }
                else
                {
                    await dal.DeleteOrderAsync();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);
            }
        }

        public async Task OrdersWindowLoad(ContentControl mw)
        {
            try
            {
                mw.Content = await dal.SqlCommandOrdersPageAsync("SELECT * FROM OrderInfo", "OrderInfo");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void ButtonShowAll_Click(object sender, RoutedEventArgs e)
        {
            await OrdersWindowLoad(mw);
            if (TextBox5.Text != string.Empty)
            {
                TextBox5.Clear();
            }
        }

        private async void ButtonSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (TextBox5.Text == string.Empty)
                {
                    MessageBox.Show("אנא כתוב בטקסט חופשי");
                }
                else if (ComboBox5.Text == string.Empty)
                {
                    MessageBox.Show("אנא בחר מה לחפש");
                }
                else
                {
                    mw.Content = await dal.SqlCommandOrdersPageAsync($"SELECT * FROM OrderInfo WHERE [{ComboBox5.Text}] like '%{TextBox5.Text}%'", "OrderInfo");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                TextBox5.Clear();
            }
        }

        private void NumberValidationPriceBox(object sender, TextCompositionEventArgs e)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
            if (regex.IsMatch(e.Text))
            {
                MessageBox.Show("! אנא כתוב רק מספרים");
            }
        }

        private void NumberValidationQuantityBox(object sender, TextCompositionEventArgs e)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
            if (regex.IsMatch(e.Text))
            {
                MessageBox.Show("! אנא כתוב רק מספרים");
            }
        }

        private void NumberValidationOrderNumberBox(object sender, TextCompositionEventArgs e)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
            if (regex.IsMatch(e.Text))
            {
                MessageBox.Show("! אנא כתוב רק מספרים");
            }
        }

        private void NumberValidationPriceBox_Update(object sender, TextCompositionEventArgs e)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
            if (regex.IsMatch(e.Text))
            {
                MessageBox.Show("! אנא כתוב רק מספרים");
            }
        }

        private void NumberValidationQuantityBoxUpdate(object sender, TextCompositionEventArgs e)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
            if (regex.IsMatch(e.Text))
            {
                MessageBox.Show("! אנא כתוב רק מספרים");
            }
        }

        private void NumberValidationOrderNumberBoxDelete(object sender, TextCompositionEventArgs e)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
            if (regex.IsMatch(e.Text))
            {
                MessageBox.Show("! אנא כתוב רק מספרים");
            }
        }
    }
}
