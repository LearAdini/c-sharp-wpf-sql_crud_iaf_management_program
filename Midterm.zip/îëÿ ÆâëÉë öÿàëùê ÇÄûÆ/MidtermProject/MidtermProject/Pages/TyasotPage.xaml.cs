﻿using MidtermProject.DataAccessLayer;
using System.Windows;
using System.Windows.Controls;

namespace MidtermProject.Pages
{
    public partial class TyasotPage : Page
    {
        static DAL dal = new DAL();
        public TyasotPage()
        {
            InitializeComponent();
    
        }
       
        private async void btn_253_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_253");
        }

        private async void btn_101_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_101");
        }

        private async void btn_102_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_102");
        }

        private async void btn_115_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_115");
        }

        private async void btn_116_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_116");
        }

        private async void btn_110_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_110");
        }

        private async void btn_109_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_109");
        }

        private async void btn_119_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_119");
        }

        private async void btn_117_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_117");
        }

        private async void btn_105_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_105");
        }

        private async void btn_201_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_201");
        }

        private async void btn_133_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_133");
        }

        private async void btn_107_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_107");
        }

        private async void btn_193_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_193");
        }

        private async void btn_106_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_106");
        }

        private async void btn_69_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_69");
        }

        private async void btn_124_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_124");

        }

        private async void btn_113_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_113");
        }

        private async void btn_118_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_118");
        }

        private async void btn_190_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_190");
        }

        private async void btn_100_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_100");
        }

        private async void btn_123_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_123");
        }

        private async void btn_114_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_114");
        }

        private async void btn_122_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_122");
        }

        private async void btn_161_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_161");
        }

        private async void btn_103_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_103");
        }

        private async void btn_120_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_120");
        }

        private async void btn_131_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_131");

        }

        private async void btn_210_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_210");
        }

        private async void btn_redBarom_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_%D7%94%D7%91%D7%A8%D7%95%D7%9F_%D7%94%D7%90%D7%93%D7%95%D7%9D");
        }

        private async void btn_200_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_200");
        }

        private async void btn_166_Click(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%98%D7%99%D7%99%D7%A1%D7%AA_166");
        }
    }
}
