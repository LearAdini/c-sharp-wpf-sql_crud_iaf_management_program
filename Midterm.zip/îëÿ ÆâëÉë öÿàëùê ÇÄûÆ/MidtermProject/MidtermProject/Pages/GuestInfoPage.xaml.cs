﻿using MidtermProject.DataAccessLayer;
using System.Windows.Controls;

namespace MidtermProject.Pages
{
    public partial class GuestInfoPage : Page
    {
        private static DAL dal = new DAL();
        public GuestInfoPage()
        {
            InitializeComponent();          
        }       
    }
}
