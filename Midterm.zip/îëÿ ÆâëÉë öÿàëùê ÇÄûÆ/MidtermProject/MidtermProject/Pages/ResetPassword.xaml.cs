﻿using MidtermProject.DataAccessLayer;
using MidtermProject.Utilities;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace MidtermProject.Pages
{
    public partial class ResetPassword : Window
    {
        private DAL dal = new DAL();
        private static System.Text.RegularExpressions.Regex _regexPass;

        public ResetPassword()
        {
            InitializeComponent();
        }


        private async void btnUpdatePassword_Click(object sender, RoutedEventArgs e)
        {
            if (!_regexPass.IsMatch(password.Password))
            {
                MessageBox.Show("! על הסיסמה להכיל 8 תווים עם אות גדולה וקטנה אחת לפחות");
            }
            else if (passwordConfirm.Password == string.Empty)
            {
                MessageBox.Show("אנא וואדא כי מלאת אימות סיסמה");
            }
            else if (password.Password != passwordConfirm.Password)
            {
                MessageBox.Show("אנא וודא כי הסיסמאות תואמאות");
            }

            else if (code.Password != EmailConfirmation.CODE)
            {
                MessageBox.Show("! אנא וודא כי הקוד נכון ובאותיות גדולות בלבד");
            }         

            else if (password.Password == passwordConfirm.Password && code.Password == EmailConfirmation.CODE)
            {
                await resetPasswordAsync();

            }
        }

        #region resetPassworAsync:
        ///Will execute the stored procedure sp_ResetPassword which is created in the migration file.
        ///It will update the password where the email is equal to the given email as in the page before(GetCodePage) only if the codes text box is correct..
        ///The get code page will tell us if the account already exists in the database or not, so you would not be able to get to this stage if count was 0, meaning the user does not exists.
        #endregion      
        public async Task resetPasswordAsync()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("sp_ResetPassword", dal._SqlCon);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@password", password.Password);

                cmd.Parameters.AddWithValue("@email", ResetPasswordModel.email); // ResetPasswordModel is a nested class inside GetCodePage.cs 


                await dal._SqlCon.OpenAsync();


                await cmd.ExecuteNonQueryAsync();

                MessageBox.Show("! סיסמה עודכנה בהצלחה");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                this.Hide();
                await dal.CheckConnectionStatusAsync();

                LoginPage lp = new();
                lp.Show();
            }
        }

        private void RegMouseIn(object sender, MouseEventArgs e)
        {
            btnUpdatePassword.Background = Brushes.DarkOrange;
            btnUpdatePassword.Foreground = dal.customColor;
        }

        private void RegMouseLeave(object sender, MouseEventArgs e)
        {
            btnUpdatePassword.Background = dal.customColor;
            btnUpdatePassword.Foreground = Brushes.White;
        }

        private async void btnBack_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("          ? האם ברצונך לחזור לעמוד הראשי", "                                     חזרה לעמוד כניסה", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                e.Handled = false;
                LoginPage lp = new LoginPage();
                await dal.CheckConnectionStatusAsync();
                this.Hide();
                lp.Show();
            }
            else
            {
                e.Handled = true;
            }
        }

        private async void WindowResetPassword_Closed(object sender, EventArgs e)
        {
            await dal.CheckConnectionStatusAsync();
            App.Current.Shutdown();
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }

        private void WindowResetPassword_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (MessageBox.Show("              ? האם ברצונך לצאת", "                                          יציאה", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                e.Cancel = false;
            else
                e.Cancel = true;
        }

        private void PasswordValidationPasswordBox(object sender, TextCompositionEventArgs e)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(@"(?=.*?[a-z])(?=.*?[A-Z]).{8,}");// (?=.*?[a-z]) checks if theres at least one/any lower case character,
            e.Handled = regex.IsMatch(e.Text);                                                                                      // (?=.*?[A-Z]) checks if theres at least one/any upper case character,
            _regexPass = regex;
        }
    }
}
