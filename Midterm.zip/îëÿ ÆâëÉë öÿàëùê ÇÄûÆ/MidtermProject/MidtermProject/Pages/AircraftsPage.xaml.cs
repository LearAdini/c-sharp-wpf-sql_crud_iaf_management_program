﻿using MidtermProject.DataAccessLayer;
using System.Windows;
using System.Windows.Controls;

namespace MidtermProject.Pages
{
    public partial class AircraftsPage : Page
    {
        static DAL dal = new DAL();
        public AircraftsPage()
        {
            InitializeComponent();
        }

        private async void btn_F15bazClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%9E%D7%A7%D7%93%D7%95%D7%A0%D7%9C_%D7%93%D7%90%D7%92%D7%9C%D7%A1_F-15_%D7%90%D7%99%D7%92%D7%9C");
        }


        private async void btn_F15iRaamClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%9E%D7%A7%D7%93%D7%95%D7%A0%D7%9C_%D7%93%D7%90%D7%92%D7%9C%D7%A1_F-15_%D7%90%D7%99%D7%92%D7%9C#F-15I");
        }

        private async void btn_F16iSufaClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%92%27%D7%A0%D7%A8%D7%9C_%D7%93%D7%99%D7%99%D7%A0%D7%9E%D7%99%D7%A7%D7%A1_F-16_%D7%A4%D7%99%D7%99%D7%98%D7%99%D7%A0%D7%92_%D7%A4%D7%9C%D7%A7%D7%95%D7%9F#F-16I");
        }

        private async void btn_F16barakClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%92%27%D7%A0%D7%A8%D7%9C_%D7%93%D7%99%D7%99%D7%A0%D7%9E%D7%99%D7%A7%D7%A1_F-16_%D7%A4%D7%99%D7%99%D7%98%D7%99%D7%A0%D7%92_%D7%A4%D7%9C%D7%A7%D7%95%D7%9F#%D7%93%D7%92%D7%9E%D7%99%D7%9D");
        }

        private async void btn_F35iAdirClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%9C%D7%95%D7%A7%D7%94%D7%99%D7%93_%D7%9E%D7%A8%D7%98%D7%99%D7%9F_F-35_%D7%9C%D7%99%D7%99%D7%98%D7%A0%D7%99%D7%A0%D7%92_II#%D7%A9%D7%99%D7%A8%D7%95%D7%AA_%D7%91%D7%97%D7%99%D7%9C_%D7%94%D7%90%D7%95%D7%95%D7%99%D7%A8_%D7%94%D7%99%D7%A9%D7%A8%D7%90%D7%9C%D7%99");
        }

        private async void btn_C130karnafClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%9C%D7%95%D7%A7%D7%94%D7%99%D7%93_C-130_%D7%94%D7%A8%D7%A7%D7%95%D7%9C%D7%A1#%D7%A9%D7%99%D7%A8%D7%95%D7%AA_%D7%9E%D7%91%D7%A6%D7%A2%D7%99");
        }

        private async void btn_C130JshemshonClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%9C%D7%95%D7%A7%D7%94%D7%99%D7%93_%D7%9E%D7%A8%D7%98%D7%99%D7%9F_C-130J_%D7%A1%D7%95%D7%A4%D7%A8_%D7%94%D7%A8%D7%A7%D7%95%D7%9C%D7%A1#%D7%A9%D7%99%D7%A8%D7%95%D7%AA_%D7%91%D7%97%D7%99%D7%9C_%D7%94%D7%90%D7%95%D7%95%D7%99%D7%A8_%D7%94%D7%99%D7%A9%D7%A8%D7%90%D7%9C%D7%99");
        }

        private async void btn_AH64PatanClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%91%D7%95%D7%90%D7%99%D7%A0%D7%92_AH-64_%D7%90%D7%A4%D7%90%D7%A6%27%D7%99#%D7%99%D7%A9%D7%A8%D7%90%D7%9C");
        }

        private async void btn_AH64dSharafClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%91%D7%95%D7%90%D7%99%D7%A0%D7%92_AH-64_%D7%90%D7%A4%D7%90%D7%A6%27%D7%99#%D7%99%D7%A9%D7%A8%D7%90%D7%9C");
        }

        private async void btn_CH53YasurClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%A1%D7%99%D7%A7%D7%95%D7%A8%D7%A1%D7%A7%D7%99_CH-53_%D7%A1%D7%99_%D7%A1%D7%98%D7%9C%D7%99%D7%95%D7%9F#%D7%99%D7%A9%D7%A8%D7%90%D7%9C");
        }

        private async void btn_UH60yanshufClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%A1%D7%99%D7%A7%D7%95%D7%A8%D7%A1%D7%A7%D7%99_UH-60_%D7%91%D7%9C%D7%A7%D7%94%D7%95%D7%A7#%D7%94%D7%99%D7%A0%D7%A9%D7%95%D7%A3_%D7%91%D7%A9%D7%99%D7%A8%D7%95%D7%AA_%D7%97%D7%99%D7%9C-%D7%94%D7%90%D7%95%D7%95%D7%99%D7%A8_%D7%94%D7%99%D7%A9%D7%A8%D7%90%D7%9C%D7%99");
        }

        private async void btn_AS565atalefClick(object sender, RoutedEventArgs e)
        {
            await dal.OpenBrowserAsync("https://he.wikipedia.org/wiki/%D7%99%D7%95%D7%A8%D7%95%D7%A7%D7%95%D7%A4%D7%98%D7%A8_AS-565_%D7%A4%D7%A0%D7%AA%D7%A8#%D7%A9%D7%99%D7%A8%D7%95%D7%AA_%D7%9E%D7%91%D7%A6%D7%A2%D7%99");
        }
  
    }
}
