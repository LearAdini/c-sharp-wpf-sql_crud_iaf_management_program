﻿using MidtermProject.DataAccessLayer;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace MidtermProject.Pages
{
    public partial class SoldiersPage : Page
    {
        private static DAL dal = new DAL();

        static MainPage mw = new MainPage();

        public SoldiersPage()
        {
            InitializeComponent();
            TextBox5.CharacterCasing = CharacterCasing.Lower;
        }


        private async void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (TextBox1.Text == string.Empty || TextBox2.Text == string.Empty || GiusDate.Text == string.Empty || BrithDateHayal.Text == string.Empty || TextBoxTaz.Text == string.Empty)
                {
                    MessageBox.Show("! אנא וודא כי מלאת את כל השדות");
                }

                else if (TextBox1.Text == string.Empty)
                {
                    MessageBox.Show("! אנא וודא כי מלאת את שם הפרטי");
                }

                else if (TextBox2.Text == string.Empty)
                {
                    MessageBox.Show("! אנא וודא כי מלאת את שם המשפחה");
                }

                else if (TextBoxTaz.Text == string.Empty)
                {
                    MessageBox.Show("! אנא וודא כי מלאת את תעודת הזהות");
                }

                else if (GiusDate.Text == string.Empty || BrithDateHayal.Text == string.Empty)
                {
                    MessageBox.Show("! אנא וודא כי מלאת את תאריך הלידה ותאריך הגיוס");
                }

                else
                {
                    await dal.AddSoldierAsync();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private async void ButtonUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (TextBox1_Copy.Text == string.Empty || TextBox2_Copy.Text == string.Empty || GiusDate_Copy.Text == string.Empty || BrithDateHayal_Copy.Text == string.Empty)
                {
                    MessageBox.Show("! אנא וודא כי מלאת את כל השדות לעידכון");
                }

                else if (GiusDate_Copy.Text == string.Empty || BrithDateHayal_Copy.Text == string.Empty)
                {
                    MessageBox.Show("! אנא וודא כי מלאת את תאריך הלידה ותאריך הגיוס לעידכון");
                }

                else if (TextBox1_Copy.Text == string.Empty || TextBox6.Text == string.Empty)
                {
                    MessageBox.Show("! אנא וודא כי מלאת את השם פרטי");
                }

                else if (TextBox2_Copy.Text == string.Empty || TextBox7.Text == string.Empty)
                {
                    MessageBox.Show("! אנא וודא כי מלאת את שם המשפחה");
                }

                else if (TextBox6.Text == string.Empty || TextBox7.Text == string.Empty || TextBoxTazOld.Text == string.Empty)
                {
                    MessageBox.Show("! אנא וודא כי מלאת את כל הפרטים הישנים");
                }

                else if (TextBoxTazOld.Text == string.Empty)
                {
                    MessageBox.Show("! אנא וודא כי מלאת את תעודת הזהות");
                }

                else
                {
                    await dal.UpdateSoldiersAsync();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private async void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (TextBoxTazDel.Text == string.Empty || TextBoxNameDel.Text == string.Empty || TextBoxLastNameDel.Text == string.Empty)
                {
                    MessageBox.Show("! אנא וודא כי מלאת את השדות למחיקה");
                }

                else
                {
                    await dal.DeleteSoldierAsync();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);
            }
        }


        public async Task SoldierWindowLoad(ContentControl mw)
        {
            try
            {
                mw.Content = await dal.SqlCommandSoldiersPageAsync("SELECT * FROM SoldierInfo ORDER BY עיר__מגורים", "SoldierInfo");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void ButtonShowAll_Click(object sender, RoutedEventArgs e)
        {
            await SoldierWindowLoad(mw);
            if (TextBox5.Text != string.Empty)
            {
                TextBox5.Clear();
            }
        }

        private async void ButtonSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (TextBox5.Text == string.Empty)
                {
                    MessageBox.Show("אנא כתוב בטקסט חופשי");
                }

                else if (ComboBox5.Text == string.Empty)
                {
                    MessageBox.Show("אנא בחר מה לחפש");
                }

                else if (ComboBox5.Text == "תז")
                {
                    mw.Content = await dal.SqlCommandSoldiersPageAsync($"SELECT * FROM SoldierInfo WHERE תז = {TextBox5.Text}", "SoldierInfo");
                }

                else if (ComboBox5.Text == "שנת גיוס")
                {
                    mw.Content = await dal.SqlCommandSoldiersPageAsync($"SELECT * FROM SoldierInfo WHERE תאריך__גיוס like '%{TextBox5.Text}%' ORDER BY עיר__מגורים", "SoldierInfo");
                }
                else if (ComboBox5.Text == "שנת לידה")
                {
                    mw.Content = await dal.SqlCommandSoldiersPageAsync($"SELECT * FROM SoldierInfo WHERE תאריך__לידה like '%{TextBox5.Text}%' ORDER BY עיר__מגורים", "SoldierInfo");
                }

                else if (TextBox5.Text == "נקבה")
                {
                    mw.Content = await dal.SqlCommandSoldiersPageAsync($"SELECT * FROM SoldierInfo WHERE מין = 'נ' ORDER BY עיר__מגורים", "SoldierInfo");
                }
                else if (TextBox5.Text == "זכר")
                {
                    mw.Content = await dal.SqlCommandSoldiersPageAsync($"SELECT * FROM SoldierInfo WHERE מין = 'ז' ORDER BY עיר__מגורים", "SoldierInfo");
                }

                else if (TextBox5.Text == "female")
                {
                    mw.Content = await dal.SqlCommandSoldiersPageAsync($"SELECT * FROM SoldierInfo WHERE מין = 'F' ORDER BY עיר__מגורים", "SoldierInfo");
                }
                else if (TextBox5.Text == "male")
                {
                    mw.Content = await dal.SqlCommandSoldiersPageAsync($"SELECT * FROM SoldierInfo WHERE מין = 'M' ORDER BY עיר__מגורים", "SoldierInfo");
                }

                else if (ComboBox5.Text == "קבע" && TextBox5.Text == "yes" )
                {
                    mw.Content = await dal.SqlCommandSoldiersPageAsync($"SELECT * FROM SoldierInfo WHERE קבע = 'Y' ORDER BY עיר__מגורים", "SoldierInfo");
                }
                else if (ComboBox5.Text == "קבע" && TextBox5.Text == "no")
                {
                    mw.Content = await dal.SqlCommandSoldiersPageAsync($"SELECT * FROM SoldierInfo WHERE קבע = 'N' ORDER BY עיר__מגורים", "SoldierInfo");
                }

                else
                {
                    mw.Content = await dal.SqlCommandSoldiersPageAsync($"SELECT * FROM SoldierInfo WHERE {ComboBox5.Text} = '{TextBox5.Text}' ORDER BY עיר__מגורים", "SoldierInfo");
                }
            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

            finally
            {
                TextBox5.Clear();
            }
        }

        private void NumberValidationTazBoxAdd(object sender, TextCompositionEventArgs e)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
            if (regex.IsMatch(e.Text))
            {
                MessageBox.Show("! אנא כתוב רק מספרים");
            }
        }

        private void NumberValidationTazBoxUpdate(object sender, TextCompositionEventArgs e)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
            if (regex.IsMatch(e.Text))
            {
                MessageBox.Show("! אנא כתוב רק מספרים");
            }
        }

        private void NumberValidationTazBoxDelete(object sender, TextCompositionEventArgs e)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
            if (regex.IsMatch(e.Text))
            {
                MessageBox.Show("! אנא כתוב רק מספרים");
            }
        }
    }
}