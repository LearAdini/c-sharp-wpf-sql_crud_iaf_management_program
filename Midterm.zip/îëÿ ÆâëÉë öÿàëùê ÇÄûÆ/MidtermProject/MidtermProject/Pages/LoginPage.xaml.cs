﻿using MidtermProject.DataAccessLayer;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using MidtermProject.Utilities.StateMachines;

namespace MidtermProject.Pages
{
    public partial class LoginPage : Window
    {
        private DAL dal = new DAL();
       
        public static string _userName { get; set; }



        public static LoginPage lp;

        public LoginPage()
        {
            InitializeComponent();
            txtUserName.CharacterCasing = System.Windows.Controls.CharacterCasing.Lower;
        }


        /// btnSubmit_Click - using ADO.NET stored procedure, checking if user exists in database. the stored procedure is generated via raw sql code in the migration file..
        /// sp_LoginUserHash is a StoredProcedure which tells if any user name with the given userName and password exists.
        /// If user exist(count==1) log into the guest main page, else if user&password equals to admin log into the admin page.
        /// Otherwise meaning user does not exists in the database: get the message "שם משתמש או סיסמה אינם נכונים"
        private async void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                await dal._SqlCon.OpenAsync();

                SqlCommand cmd = new SqlCommand("sp_LoginUserHash", dal._SqlCon);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@userName", txtUserName.Text);

                cmd.Parameters.AddWithValue("@password", txtPassword.Password);


                int count = Convert.ToInt32(await cmd.ExecuteScalarAsync());

                if (count == 1)
                {
                    GuestPage gp = new();
                    gp.Show();
                    this.Hide();                
                    _userName = txtUserName.Text;
                }

                else if (txtUserName.Text == "admin" && txtPassword.Password == "admin")
                {
                    MainPage mp = new();
                    mp.Show();
                    this.Hide();
                }

                else
                {
                    MessageBox.Show("! שם משתמש או סיסמה אינם נכונים");
                    _StateContext stateContext = new(new LoginMachine()); //I placed stateContext here because I want each time that username/password is wrong to display the state machines state,if it was a property it would only show the new state context once(after button is trigerred).So instead I made a new _StateContext here, so each time button login is being pressed with the wrong/correct credential a new login state will appear.
                    stateContext.LoginFailed();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                await dal.CheckConnectionStatusAsync();
            }

        }

        /// btnRegister_Click: When Register(הרשמה) button is clicked, open RegisterPage and close this login page
        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            dal.PageRegister.Show();
            this.Hide();
        }

        /// btn_LoginMouseEnter: When mouse enters the Login(התחבר) button change background from white to my custom made color(dark gray ish)
        private void btn_LoginMouseEnter(object sender, MouseEventArgs e)
        {
            btnSubmit.Background = dal.customColor;
            btnSubmit.Foreground = Brushes.White;
        }
        /// btn_LoginMouseLeave: When mouse is leaving the Login button corners revert back to white as background color and foreground color as my custom color
        private void btn_LoginMoseLeave(object sender, MouseEventArgs e)
        {
            btnSubmit.Background = Brushes.White;
            btnSubmit.Foreground = dal.customColor;
        }

        /// btn_RegMouseEnter: When mouse enters the Register(הירשם) button change background from my custom color to DarkOrange and foreground color to my custom color
        private void btn_RegMouseEnter(object sender, MouseEventArgs e)
        {
            btnRegister.Background = Brushes.DarkOrange;
            btnRegister.Foreground = dal.customColor;
        }

        /// btn_RegMouseLeave: When mouse is leaving the Register button corners revert back to my custom color as background color and foreground color as white
        private void btn_RegMouseLeave(object sender, MouseEventArgs e)
        {
            btnRegister.Background = dal.customColor;
            btnRegister.Foreground = Brushes.White;
        }
        /// btn_ResetPassword_Click: When reset password button is clicked, open up GetCodePage and close this page
        private void btn_ResetPassword_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            GetCodePage getCode = new();
            getCode.Show();
        }

        private async void WindowLogin_Closed(object sender, EventArgs e)
        {
            await dal.CheckConnectionStatusAsync();
            App.Current.Shutdown();
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }

        private void WindowLogin_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (MessageBox.Show("              ? האם ברצונך לצאת", "                                          יציאה", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                e.Cancel = false;
            else
                e.Cancel = true;
        }
    }
}
