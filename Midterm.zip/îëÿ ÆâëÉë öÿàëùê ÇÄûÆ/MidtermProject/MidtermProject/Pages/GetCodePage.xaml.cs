﻿using MidtermProject.DataAccessLayer;
using MidtermProject.Utilities;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace MidtermProject.Pages
{
    public partial class GetCodePage : Window
    {
        private DAL dal = new DAL();

        public EmailConfirmation _email = new EmailConfirmation();


        public GetCodePage()
        {
            InitializeComponent();
        }

        private async void btnSendCode_Click(object sender, RoutedEventArgs e)
        {
            if (!email.Text.Contains("@"))
            {
                MessageBox.Show("אנא וודא כי הזנת כתובת אימייל נכונה");
            }
            else if (email.Text == string.Empty)
            {
                MessageBox.Show("! אנא וודא כי מלאת את כל השדות");
            }
            else if (email.Text != string.Empty)
            {
                await checkEmail();
            }
        }

        private async Task checkEmail()
        {
            try
            {          
                await dal._SqlCon.OpenAsync();

                SqlCommand cmd = new SqlCommand("sp_VerifyEmail", dal._SqlCon);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@email", email.Text);

                ResetPasswordModel.email = email.Text;

                int count = Convert.ToInt32(await cmd.ExecuteScalarAsync());

                if (count == 1)
                {
                    _email.sendEmail(email.Text);// sendEmail function sending the code to the specified email   
                    ResetPassword rp = new ResetPassword();
                    this.Hide();
                    rp.Show();
                }
                else
                {
                    MessageBox.Show("אימייל זה אינו קיים במערכת !");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                await dal.CheckConnectionStatusAsync();
            }
        }

        private async void btnBack_Click(object sender, RoutedEventArgs e)
        {
            await dal.CheckConnectionStatusAsync();
            this.Hide();
            LoginPage lp = new();
            lp.Show();
        }

        private void RegMouseIn(object sender, MouseEventArgs e)
        {
            btnSendCode.Background = Brushes.DarkOrange;
            btnSendCode.Foreground = dal.customColor;
        }

        private void RegMouseLeave(object sender, MouseEventArgs e)
        {
            btnSendCode.Background = dal.customColor;
            btnSendCode.Foreground = Brushes.White;
        }

        private async void WindowGetCodePage_Closed(object sender, EventArgs e)
        {
            await dal.CheckConnectionStatusAsync();
            App.Current.Shutdown();
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }

        private void WindowGetCodePage_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (MessageBox.Show("              ? האם ברצונך לצאת", "                                          יציאה", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                e.Cancel = false;
            else
                e.Cancel = true;
        }
    }


    public class ResetPasswordModel
    {
        public static string email;
    }

}

