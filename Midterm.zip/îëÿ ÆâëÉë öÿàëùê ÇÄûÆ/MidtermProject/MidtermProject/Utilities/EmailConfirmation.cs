﻿using System;
using System.Net;
using System.Net.Mail;
using System.Windows;

namespace MidtermProject.Utilities
{
    public class EmailConfirmation
    {
        static Random r = new Random();

        public static string CODE;

        public EmailConfirmation()
        {
            randomCode();
        }
        public void sendEmail(string email)
        {
            try
            {
                SmtpClient client = new SmtpClient("smtp.gmail.com");
                client.EnableSsl = true;
                MailMessage message = new MailMessage("midtermiaf@gmail.com (IAF Midterm App)", email);
                message.Body = $"Hello ! \n \nYour code is: {CODE}";
                message.Subject = "Password Reset For IAF Midterm Project";
                client.Credentials = new NetworkCredential("midtermiaf@gmail.com","Jk5%321Gfd!"); // I dont mind the password being here because its a test email for this project
                client.Port = Convert.ToInt32("587");               
                client.Send(message);
                MessageBox.Show("נשלח בהצלחה ! אנא היכנס ל'ספאם מייל' והקש את הקוד");
            }

            catch (Exception ex)
            {
                MessageBox.Show("Message could not be sent.\nThe following error was returned:\n’" + ex.Message + "‘", "Sending Failed");
            }
        }

        public static string randomCode()
        {         
            string[] numbers = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
            string[] letters = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
           
            string code = string.Empty;
            int count = 1;
            while (count < 3)
            {
                code += numbers[r.Next(numbers.Length)] += letters[r.Next(letters.Length)].ToUpper();           
                count++;
            }

            CODE = code;
            return code;
        }

    }
}


