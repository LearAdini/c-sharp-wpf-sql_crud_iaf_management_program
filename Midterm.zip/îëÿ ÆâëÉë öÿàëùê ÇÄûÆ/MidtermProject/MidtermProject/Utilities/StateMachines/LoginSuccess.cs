﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace MidtermProject.Utilities.StateMachines
{
	public class LoginSuccess : _StateMachine
	{
		public _StateMachine LoginFailed()
		{
			return new LoginFailed();
		}

		_StateMachine _StateMachine.LoginSuccess()
		{
			return this; 
		}
	}
}
