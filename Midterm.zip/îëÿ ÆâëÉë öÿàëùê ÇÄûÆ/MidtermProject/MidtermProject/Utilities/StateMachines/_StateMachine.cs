﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermProject.Utilities.StateMachines
{
	public interface _StateMachine
	{
		 _StateMachine LoginFailed();
		 _StateMachine LoginSuccess();

	}
}
