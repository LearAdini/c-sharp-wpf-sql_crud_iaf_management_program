﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermProject.Utilities.StateMachines
{
	public class _StateContext
	{
		private _StateMachine state;
		public _StateContext(_StateMachine state)
		{
			this.state = state;
		}

		public void LoginSuccess()
		{
			this.state = state.LoginSuccess();
		}

		public void LoginFailed()
		{
			this.state = state.LoginFailed();
		}

	}
}
