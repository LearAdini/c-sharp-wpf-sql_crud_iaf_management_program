﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace MidtermProject.Utilities.StateMachines
{
   public class LoginFailed: _StateMachine
	{
		public _StateMachine LoginSuccess()
		{
			return new LoginSuccess();
		}

        _StateMachine _StateMachine.LoginFailed()
        {
			return this;
		}
    }
}
