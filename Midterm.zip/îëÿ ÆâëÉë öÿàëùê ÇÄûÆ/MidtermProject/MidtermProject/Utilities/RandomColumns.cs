﻿using System;
using System.Collections.Generic;

namespace MidtermProject.Utilities
{
    public class RandomColumns
    {
        public Random r = new Random();

        public int a;
        public int b;
        public int price;
        public DateTime giusdate;
        public string name;
        public string item;
        public string type;

        public int _A { get { return this.a; } set { this.a = value; } }
        public int _B { get { return this.b; } set { this.b = value; } }


        public int total;
        private int global;
        public int _Global { get { return this.global; } set { this.global = value; } }


        public int RandomId()
        {
            //The audit digit number of an israeli id is either 2 or 3 if you were born after 1987
            int index = r.Next(200000000, 399999999);
            global = index;
            return index;
        }


        public DateTime RandomGiusDay()
        {
            DateTime start = new DateTime(2009, 1, 1);
            DateTime end = new DateTime(2018, 12, 31);
            int range = (end - start).Days;
            giusdate = start.AddDays(r.Next(range)).AddHours(r.Next(7, 10)).AddMinutes(r.Next(5, 31));
            return giusdate;
        }


        public DateTime RandomBirthDay() /// *To avoid 'parameters describe an un-representable DateTime.' error, each date of birth has only 29 days except when in Leap Year, Because if each new DateTime day limit were up to 31 days long and not 29, when date is picked randomly a soldier's birth date can be with 31 days long for February when Feb has only 28 days long except when in Leap Year (29 days for regular years and 30 days for a Leap Year because: r.Next(min,max) wont get the last value of max)..
        {
          
            var date = new DateTime();

            if (giusdate.Year == 2009) // For each year in range (2009 <= 2018) the soldier's birth date will be 18 years less then the recruit date
            {
                date = new DateTime(1991, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;
            }

            else if (giusdate.Year == 2010)
            {
                date = new DateTime(1992, r.Next(1, 13), r.Next(1, 30)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61)); // Leap Year (a Leap Year has 29 days long in February but r.Next days length is up to 30 days because the last value wont count..)
                return date;
            }

            else if (giusdate.Year == 2011)
            {
                date = new DateTime(1993, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;
            }

            else if (giusdate.Year == 2012)
            {
                date = new DateTime(1994, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;
            }

            else if (giusdate.Year == 2013)
            {
                date = new DateTime(1995, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;

            }

            else if (giusdate.Year == 2014)
            {
                date = new DateTime(1996, r.Next(1, 13), r.Next(1, 30)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));// Leap Year
                return date;

            }

            else if (giusdate.Year == 2015)
            {
                date = new DateTime(1997, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;

            }

            else if (giusdate.Year == 2016)
            {
                date = new DateTime(1998, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;

            }

            else if (giusdate.Year == 2017)
            {
                date = new DateTime(1999, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;

            }

            else if (giusdate.Year == 2018)
            {
                date = new DateTime(2000, r.Next(1, 13), r.Next(1, 30)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61)); // Leap Year
                return date;

            }

            return default;

            ///vvv Other way for getting the soldier's birth date and tell if a year is in a Leap Year or has 30/31 days long in a month, and if month is February return a date with only 28 days long except when in a Leap Year:
            #region
            /*
             
        public int random_except_list(int n, int[] x) // Exclude a certain value in range
        {
            int result = x.Length;

            for (int i = 0; i < x.Length; i++)
            {
                if (result < x[i])
                    return result;
                result++;
            }
            if (result == 0)
            {
                result += 1;
            }
            return result; /// for example give n the value of 12 and exclude 2 ,4 ,6 ,9 ,11: random_except_list(12, new int[] { 2, 4, 6, 9, 11 }) will return one of this values: 1, 3, 5, 7, 8, 10, 12
        }
             
        public DateTime RandomBirthDay()
        {
            //DateTime start = new DateTime(1991, 1, 1);
            //DateTime end = new DateTime(2000, 12, 31);
            //int range = (end - start).Days;
            //var date = start.AddDays(r.Next(range));

            date = new DateTime(r.Next(1991, 2000), r.Next(1, 12), r.Next(1, 31));

            if (giusdate.Year == 2009) // For each year in range (2009 <= 2018) the soldier's birth date will be 18 years less then the recruit date
            {
                if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11) // Only April,June,September and November are 30 days long
                {
                    return date.AddDays(r.Next(1, 30));
                }
                else if (date.Month == 2) // February is 28 days long except when in Leap year,if month is February return date month as 2 and only as 28 days long
                {
                    date = new DateTime(1991, 2, r.Next(1, 28));
                    return date;
                }
                else
                {
                    date = new DateTime(1991, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31)); // If non of the previous dates were picked, exclude the months with 28 and 29 days long(Feb,Apr,Jun,Sep,Nov) from being picked, and return a new date with possilbly 31 days long which only Jan,Mar,Jul,May,Aug,Oct,Dec(1,3,5,7,8,10,12) months have
                    return date;
                }
            }

            else if (giusdate.Year == 2010)
            {
                if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
                {
                    return date.AddDays(r.Next(1, 30));
                }
                else if (date.Month == 2)
                {
                    date = new DateTime(1992, 2, r.Next(1, 29)); // Leap Year - In a Leap Year February is 29 days long
                    return date;
                }
                else
                {
                    date = new DateTime(1992, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
                    return date;
                }
            }

            else if (giusdate.Year == 2011)
            {
                if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
                {
                    //date = new DateTime(1993, r.Next(), r.Next(1, 30));
                    return date.AddDays(r.Next(1, 30));
                }
                else if (date.Month == 2)
                {
                    date = new DateTime(1993, 2, r.Next(1, 28));
                    return date;
                }
                else
                {
                    date = new DateTime(1993, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
                    return date;

                }
            }

            else if (giusdate.Year == 2012)
            {
                if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
                {
                    return date.AddDays(r.Next(1, 30));
                }
                else if (date.Month == 2)
                {
                    date = new DateTime(1994, 2, r.Next(1, 28));
                    return date;
                }
                else
                {
                    date = new DateTime(1994, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
                    return date;
                }
            }

            else if (giusdate.Year == 2013)
            {
                if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
                {
                    return date.AddDays(r.Next(1, 30));
                }
                else if (date.Month == 2)
                {
                    date = new DateTime(1995, 2, r.Next(1, 28));
                    return date;
                }
                else
                {
                    date = new DateTime(1995, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
                    return date;
                }

            }

            else if (giusdate.Year == 2014)
            {
                if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
                {
                    return date.AddDays(r.Next(1, 30));
                }
                else if (date.Month == 2)
                {
                    date = new DateTime(1996, 2, r.Next(1, 29));//Leap Year
                    return date;
                }
                else
                {
                    date = new DateTime(1996, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
                    return date;
                }
            }

            else if (giusdate.Year == 2015)
            {
                if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
                {
                    return date.AddDays(r.Next(1, 30));
                }
                else if (date.Month == 2)
                {
                    date = new DateTime(1997, 2, r.Next(1, 28));
                    return date;
                }
                else
                {

                    date = new DateTime(1997, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
                    return date;
                }
            }

            else if (giusdate.Year == 2016)
            {
                if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
                {
                    return date.AddDays(r.Next(1, 30));
                }
                else if (date.Month == 2)
                {
                    date = new DateTime(1998, r.Next(1, 12), r.Next(1, 28));
                    return date;
                }
                else
                {
                    date = new DateTime(1998, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
                    return date;
                }
            }

            else if (giusdate.Year == 2017)
            {
                if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
                {
                    return date.AddDays(r.Next(1, 30));
                }
                else if (date.Month == 2)
                {
                    date = new DateTime(1999, 2, r.Next(1, 28));
                    return date;
                }
                else
                {
                    date = new DateTime(1999, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
                    return date;
                }
            }

            else if (giusdate.Year == 2018)
            {
                if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
                {
                    return date.AddDays(r.Next(1, 30));
                }
                else if (date.Month == 2)
                {
                    date = new DateTime(2000, 2, r.Next(1, 29));//Leap Year
                    return date;
                }
                else
                {
                    date = new DateTime(2000, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
                    return date;
                }
            }

            else
            {
                return date;
            }
        }
             */
            #endregion

            /// Draft - ways to assign birth date:
            #region
            //    DateTime start = new DateTime(1991, 1, 1);
            //    DateTime end = new DateTime(2000, 12, 31);
            //    int range = (end - start).Days;
            //    var date = start.AddDays(r.Next(range));

            //    if (giusdate.Year == 2009) // For each year in range (2009 <= 2018) the soldier's birth date will be 18 years less then the recruit date
            //    {
            //        if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11) // Only April,June,September and November are 30 days long
            //        {
            //            return new DateTime().AddYears(1991).AddDays(r.Next(1, 30));
            //        }
            //        else if (date.Month == 2) // February is 28 days long except when in Leap year,if month is February return date month as 2 and only as 28 days long
            //        {
            //            date = new DateTime(1991, 2, r.Next(1, 28));
            //            return date;
            //        }
            //        else
            //        {
            //            date = new DateTime(1991, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31)); // If non of the previous dates were picked, exclude the months with 28 and 29 days long(Feb,Apr,Jun,Sep,Nov) from being picked, and return a new date with possilbly 31 days long which only Jan,Mar,Jul,May,Aug,Oct,Dec(1,3,5,7,8,10,12) months have
            //            return date;
            //        }
            //    }

            //    else if (giusdate.Year == 2010)
            //    {
            //        if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
            //        {
            //            return new DateTime().AddYears(1992).AddDays(r.Next(1, 30));
            //        }
            //        else if (date.Month == 2)
            //        {
            //            date = new DateTime(1992, 2, r.Next(1, 29)); // Leap Year - In a Leap Year February is 29 days long
            //            return date;
            //        }
            //        else
            //        {
            //            date = new DateTime(1992, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
            //            return date;
            //        }
            //    }

            //    else if (giusdate.Year == 2011)
            //    {
            //        if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
            //        {
            //            return new DateTime().AddYears(1993).AddDays(r.Next(1, 30));
            //        }
            //        else if (date.Month == 2)
            //        {
            //            date = new DateTime(1993, 2, r.Next(1, 28));
            //            return date;
            //        }
            //        else
            //        {
            //            date = new DateTime(1993, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
            //            return date;

            //        }
            //    }

            //    else if (giusdate.Year == 2012)
            //    {
            //        if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
            //        {
            //            return new DateTime().AddYears(1994).AddDays(r.Next(1, 30));
            //        }
            //        else if (date.Month == 2)
            //        {
            //            date = new DateTime(1994, 2, r.Next(1, 28));
            //            return date;
            //        }
            //        else
            //        {
            //            date = new DateTime(1994, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
            //            return date;
            //        }
            //    }

            //    else if (giusdate.Year == 2013)
            //    {
            //        if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
            //        {
            //            return new DateTime().AddYears(1995).AddDays(r.Next(1, 30));
            //        }
            //        else if (date.Month == 2)
            //        {
            //            date = new DateTime(1995, 2, r.Next(1, 28));
            //            return date;
            //        }
            //        else
            //        {
            //            date = new DateTime(1995, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
            //            return date;
            //        }

            //    }

            //    else if (giusdate.Year == 2014)
            //    {
            //        if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
            //        {
            //            return new DateTime().AddYears(1996).AddDays(r.Next(1, 30));
            //        }
            //        else if (date.Month == 2)
            //        {
            //            date = new DateTime(1996, 2, r.Next(1, 29));//Leap Year
            //            return date;
            //        }
            //        else
            //        {
            //            date = new DateTime(1996, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
            //            return date;
            //        }
            //    }

            //    else if (giusdate.Year == 2015)
            //    {
            //        if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
            //        {
            //            return new DateTime().AddYears(1997).AddDays(r.Next(1, 30));
            //        }
            //        else if (date.Month == 2)
            //        {
            //            date = new DateTime(1997, 2, r.Next(1, 28));
            //            return date;
            //        }
            //        else
            //        {

            //            date = new DateTime(1997, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
            //            return date;
            //        }
            //    }

            //    else if (giusdate.Year == 2016)
            //    {
            //        if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
            //        {
            //            return new DateTime().AddYears(1998).AddDays(r.Next(1, 30));
            //        }
            //        else if (date.Month == 2)
            //        {
            //            date = new DateTime(1998, r.Next(1, 12), r.Next(1, 28));
            //            return date;
            //        }
            //        else
            //        {
            //            date = new DateTime(1998, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
            //            return date;
            //        }
            //    }

            //    else if (giusdate.Year == 2017)
            //    {
            //        if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
            //        {
            //            return new DateTime().AddYears(1999).AddDays(r.Next(1, 30));
            //        }
            //        else if (date.Month == 2)
            //        {
            //            date = new DateTime(1999, 2, r.Next(1, 28));
            //            return date;
            //        }
            //        else
            //        {
            //            date = new DateTime(1999, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
            //            return date;
            //        }
            //    }

            //    else if (giusdate.Year == 2018)
            //    {
            //        if (date.Month == 4 || date.Month == 6 || date.Month == 9 || date.Month == 11)
            //        {
            //            return new DateTime().AddYears(2000).AddDays(r.Next(1, 30));
            //        }
            //        else if (date.Month == 2)
            //        {
            //            date = new DateTime(2000, 2, r.Next(1, 29));//Leap Year
            //            return date;
            //        }
            //        else
            //        {
            //            date = new DateTime(2000, random_except_list(12, new int[] { 2, 4, 6, 9, 11 }), r.Next(1, 31));
            //            return date;
            //        }
            //    }

            //    else
            //    {
            //        return date;
            //    }
            //}
            #endregion
            #region
            //    if (giusdate.Year == 2009) // For each year in range (2009 <= 2018) the soldier's birth date will be 18 years less then the recruit date
            //    {
            //        var date = new DateTime(1991, r.Next(1, 12), r.Next(1, 31));
            //        return date;
            //    }

            //    else if (giusdate.Year == 2010)
            //    {
            //        var date = new DateTime(1992, r.Next(1, 12), r.Next(1, 31));
            //        return date;
            //    }

            //    else if (giusdate.Year == 2011)
            //    {
            //        var date = new DateTime(1993, r.Next(1, 12), r.Next(1, 31));
            //        return date;
            //    }

            //    else if (giusdate.Year == 2012)
            //    {
            //        var date = new DateTime(1994, r.Next(1, 12), r.Next(1, 31));
            //        return date;
            //    }

            //    else if (giusdate.Year == 2013)
            //    {
            //        var date = new DateTime(1995, r.Next(1, 12), r.Next(1, 31));
            //        return date;

            //    }

            //    else if (giusdate.Year == 2014)
            //    {
            //        var date = new DateTime(1996, r.Next(1, 12), r.Next(1, 31));
            //        return date;

            //    }

            //    else if (giusdate.Year == 2015)
            //    {
            //        var date = new DateTime(1997, r.Next(1, 12), r.Next(1, 31));
            //        return date;

            //    }

            //    else if (giusdate.Year == 2016)
            //    {
            //        var date = new DateTime(1998, r.Next(1, 12), r.Next(1, 31));
            //        return date;

            //    }

            //    else if (giusdate.Year == 2017)
            //    {
            //        var date = new DateTime(1999, r.Next(1, 12), r.Next(1, 31));
            //        return date;

            //    }

            //    else if (giusdate.Year == 2018)
            //    {
            //        var date = new DateTime(2000, r.Next(1, 12), r.Next(1, 31));
            //        return date;

            //    }


            //    return default;
            //}
            #endregion
        }


        public DateTime RandomOrderDate()
        {
            DateTime start = new DateTime(2016, 1, 1);
            int range = (DateTime.Today - start).Days;
            return start.AddDays(r.Next(range));
        }


        public string RandomRole()
        {
            if (giusdate.Year >= 2016)
            {
                var a = new List<string>{
			"טכנאי",
			"קשר"
			};
                int index = r.Next(a.Count);
                return a[index];
            }

            else
            {
                var b = new List<string>
{
			"טייס",
			"לוחמה אלקטרונית",
			"מטיס מלט"
			};
                int index = r.Next(b.Count);
                return b[index];
            }
        }


        public string RandomRank()
        {
            if (giusdate.Year >= 2016)
            {
                var a = new List<string>{
			"טרש",
			"רבט",
			"סמל",
			"סמר"
			};

                return a[r.Next(a.Count)];
            }

            else
            {
                List<string> nagad = new List<string> {
			"רסל",
			"רסר",
			"רסם",
			"רסב",
			"רנם",
			"רנג",
			"סגם",
			"סגן",
			"קמא",
			"סרן",
			"קאב",
			"רסן",
			"סאל",
			"אלם",
			"תאל",
			"אלוף"
			};
                return nagad[r.Next(nagad.Count)];
            }
        }


        public string RandomKeva()
        {
            var a = new List<string>
			{
			"כן",
			"לא"
			};
            if (giusdate.Year >= 2016)
            {
                return a[1];
            }
            else
            {
                return a[0];
            }
        }


        public string RandomFirstName()
        {
            var a = new List<string>{
			 "שרון",
			 "נעומי",
			 "נעמה",
			 "תמר",
			 "מאיה",
			 "שירה",
			 "יעל",
			 "סיוון",
			 "אמה",
			 "אביגיל",
			 "נועם",
			 "אברהם",
			 "עומר",
			 "סתיו",
			 "דימיטרי",
			 "יונתן",
			 "שחף",
			 "איתי",
			 "דניאל",
			 "עומרי",
			 "סמואל",
			 "שמואל",
			 "יוני",
			 "אבי",
			 "אריאל",
			 "גפן",
			 "רפאל",
			 "אהרון",
			 "דוד",
			 "משה",
			 "רועי",
			 "אור",
			 "בר",
			 "גל",
			 "חן",
			 "יניב",
			 "עידן",
			 "שי",
			 "תום",
			 "אלעד",
			 "אמנון",
			 "אילן",
			 "מירון",
			 "צור",
			 "דילן",
 			 "דימה",
 			 "מקס",
			 "עמנואל",
			 "שון"
			};
            int index = r.Next(a.Count);
            name = a[index];

            return a[index];
        }


        public string RandomLastName()
        {
            var a = new List<string>{
			"לוי",
			"כהן",
			"שמואלי",
			"אברהמי",
			"בן אברהם",
			"לייבוביץ",
			"צימרמן",
			"קרמר",
			"טליסמן",
			"קליין",
			"חסן",
			"אזולאי",
			"מזרחי",
			"פרץ",
			"ביטון",
			"דיאטלוב",
			"וסילנקו",
			"פדורוב",
			"ספסקי",
			"שטיין",
			"באום",
			"אלכסנדר",
			"לנצמן",
			"קולמן",
			"הולצמן",
			"דמסקי",
			"קונפורטי",
			"צוקרמן",
			"ניומן",
			"וייס"
			};
            int index = r.Next(a.Count);
            return a[index];
        }


        public string RandomCity()
        {
            var a = new List<string>{
			"חיפה",
			"תל אביב יפו",
			"חולון",
			"ראשון לציון",
			"נהריה",
			"אשדוד",
			"באר שבע",
			"נתניה",
			"סביון",
			"ירושלים",
			"רמת גן",
			"כפר סבא",
			"מודיעין",
			"הוד השרון",
			"נוף הגליל",
			"גבעת שמואל"
			};
            int index = r.Next(a.Count);
            return a[index];
        }

        public string RandomStreet()
        {
            int streetNumber = r.Next(1, 120);

            var a = new List<string>{
			$"בן גוריון {streetNumber}",
			$"המלך גורג {streetNumber} ",
			$"חיים ויצמן {streetNumber}",
			$"זבוטינסקי {streetNumber}",
			$"מנחם בגין {streetNumber}",
			$"ביאליק {streetNumber}",
			$"סוקולוב {streetNumber}",
			$"הזית {streetNumber}",
			$"הרימון {streetNumber}",
			$"התמר {streetNumber}",
			$"המסגר {streetNumber}",
			$"הגפן {streetNumber}",
			$"שאול המלך {streetNumber}",
			$"המלך דוד {streetNumber}",
			$"המלך שלמה {streetNumber}",
			$"שטראוס {streetNumber}"
			};
            int index = r.Next(a.Count);
            return a[index];
        }


        public string RandomGender()
        {
            var a = new List<string>{
			"ז",
			"נ"
			};

            if (name == "אביגיל" || name == "שרון" || name == "נעומי" || name == "אמה" || name == "סיוון" ||
            name == "נעמה" || name == "תמר" || name == "מאיה" || name == "יעל" || name == "שירה")
            {
                return a[1];
            }
            else
            {
                return a[0];
            }
        }


        public string RandomOrderType()
        {
            var a = new List<string>{
			"נשק",
			"תחמושות",
			"טילים",
			"כלים",
			"מוצרי ניקיון"
			};
            int index = r.Next(a.Count);

            type = a[index];

            return a[index];
        }


        public string RandomOrderProduct()
        {

            var weapons = new List<string>{
			"M4A1",
			"Glock"
			};

            var bullets = new List<string>{
			"556x45",
			"9x19mm",
			"762x39"
			};

            var rockets = new List<string>
			{
			"AGM-88",
			"AIM-120",
			"IRIS-T",
			"AIM-9X"
			};

            var parts = new List<string>{
			"מפתחות אלן",
			"מברג פיליפס",
			"מפתח שוודי",
			"מבער גז"
			};

            var cleaning = new List<string>
			{
			"סבון",
			"סקוצים",
			"סמרטוט",
			"אקונומיקה"
			};

            if (type == "נשק")
            {
                int index = r.Next(weapons.Count);
                item = weapons[index];
                return weapons[index];
            }
            else if (type == "תחמושות")
            {
                int index = r.Next(bullets.Count);
                item = bullets[index];
                return bullets[index];
            }

            else if (type == "טילים")
            {
                int index = r.Next(rockets.Count);
                item = rockets[index];
                return rockets[index];
            }

            else if (type == "כלים")
            {
                int index = r.Next(parts.Count);
                item = parts[index];
                return parts[index];
            }

            else if (type == "מוצרי ניקיון")
            {
                int index = r.Next(cleaning.Count);
                item = cleaning[index];
                return cleaning[index];
            }

            return default;
        }


        public int RandomOrderQuantity()
        {

            if (item == "M4A1")
            {
                a = r.Next(10, 70);

                return a;
            }

            else if (item == "Glock")
            {
                a = r.Next(15, 125);

                return a;
            }

            else if (type == "כלים")
            {
                a = r.Next(5, 20);

                return a;
            }

            else if (type == "מוצרי ניקיון")
            {
                a = r.Next(25, 500);

                return a;
            }

            else if (type == "טילים")
            {
                a = r.Next(10, 350);

                return a;
            }

            else
            {
                a = r.Next(15, 500);
                return a;
            }

        }


        public int RandomOrderPricePerUnit()
        {
            if (type == "תחמושות")
            {
                b = r.Next(45, 200);

                return b;
            }
            else if (type == "כלים")
            {
                b = r.Next(100, 500);
                return b;
            }
            else if (item == "סקוצים")
            {
                b = 5;
                return b;
            }
            else if (item == "אקונומיקה")
            {
                b = 25;
                return b;
            }
            else if (item == "סבון")
            {
                b = 12;
                return b;
            }
            else if (item == "סמרטוט")
            {
                b = 10;
                return b;
            }
            else if (item == "M4A1")
            {
                b = 4700;

                return b;
            }
            else if (item == "Glock")
            {
                b = 2200;

                return b;
            }
            else
            {
                b = r.Next(2800, 12000);
                return b;
            }
        }

        public int TotalOrderPrice()
        {
            total = this._A * this._B;
            return total;
        }


        /// Start of random columns  in english
        public string RandomFirstName_en()
        {
            var a = new List<string>{
			 "Sharon",
			 "Neomi",
			 "Neama",
			 "Tamar",
			 "Maya",
			 "Shira",
			 "Yael",
			 "Sivan",
			 "Emma",
			 "Avigail",
			 "Noam",
			 "Avraham",
			 "Omer",
			 "Stav",
			 "Dimitri",
			 "Jonathan",
			 "Shahaf",
			 "Itay",
			 "Daniel",
			 "Omri",
			 "Samuel",
			 "Shmuel",
			 "Yoni",
			 "Avi",
			 "Ariel",
			 "Gefen",
			 "Rafael",
			 "Aharon",
			 "Daviv",
			 "Moshe",
			 "Roi",
			 "Or",
			 "Bar",
			 "Gal",
			 "Hen",
			 "Yaniv",
			 "Idan",
			 "Shai",
			 "Tom",
			 "Elad",
			 "Amnon",
			 "Ilan",
			 "Miron",
			 "Tzur",
			 "Dylan",
			 "Dima",
			 "Max",
			 "Emmanuel",
			 "Shuan"
			};
            int index = r.Next(a.Count);
            name = a[index];

            return a[index];
        }

        public string RandomLastName_en()
        {
            var a = new List<string>{
			"Levi",
			"Cohen",
			"Shmueli",
			"Avrahami",
			"Ben Avraham",
			"Leibowitz",
			"Zimmerman",
			"Kremer",
			"Talisman",
			"Klein",
			"Hasan",
			"Azulay",
			"Mizrahi",
			"Perez",
			"Biton",
			"Diatlov",
			"Vasilenko",
			"Podorov",
			"Spassky",
			"Verchenova",
			"Shtein",
			"Baom",
			"Alexander",
			"Lansmann",
			"Kolman",
			"Holtzmann",
			"Damsky",
			"Konforti",
			"Zuckerman",
			"Neumann",
			"Weiss"
			};
            int index = r.Next(a.Count);
            return a[index];
        }

        public string RandomCity_en()
        {
            var questions = new List<string>{
			"Haifa",
			"Tel Aviv Yafo",
			"Holon",
			"Rishon LeZion",
			"Nahariya",
			"Ashdod",
			"Beer Sheva",
			"Netanya",
			"Savion",
			"Jerusalem",
			"Ramat Gan",
			"Kfar Saba",
			"Modiin",
			"Hod Hasharon",
			"Nof HGalil",
			"Givat Shmuel"
			};
            int index = r.Next(questions.Count);
            return questions[index];
        }

        public string RandomStreet_en()
        {
            int streetNumber = r.Next(1, 120);

            var a = new List<string>{
			$"Ben Gurion {streetNumber}",
			$"King George {streetNumber}",
			$"Haim Weizmann {streetNumber}",
			$"Jabotinsky {streetNumber}",
			$"Menahem Begin {streetNumber}",
			$"Bialik {streetNumber}",
			$"Sokolov {streetNumber}",
			$"HaZait {streetNumber}",
			$"HaRimon {streetNumber}",
			$"HaTamar {streetNumber}",
			$"HaMasger {streetNumber}",
			$"HaGefen{streetNumber}",
			$"Shaul Hamelech {streetNumber}",
			$"King Daviv {streetNumber}",
			$"King Solomon {streetNumber}",
			$"Shtraus {streetNumber}"
			};
            int index = r.Next(a.Count);
            return a[index];
        }

        public string RandomRole_en()
        {
            if (giusdate.Year >= 2016)
            {
                var a = new List<string>{
			"Technician",
			"Signaler"
			};
                int index = r.Next(a.Count);
                return a[index];
            }

            else
            {
                var b = new List<string>{
			"Pilot",
			"Electronic Warfare",
			"Drone Pilot",
			};
                int index = r.Next(b.Count);
                return b[index];
            }
        }

        public string RandomRank_en()
        {
            if (giusdate.Year >= 2016)
            {
                var a = new List<string>{
			"Turai",
			"Rabat",
			"Samal",
			"Samar"
			};

                return a[r.Next(a.Count)];
            }
            else
            {
                List<string> nagad = new List<string> {
			"Rasal",
			"Rasar",
			"Rasam",
			"Rasab",
			"Ranam",
			"Ranag",
			"Sagam",
			"Segen",
			"Kma",
			"Seren",
			"kab",
			"Rasan",
			"Saal",
			"Alam",
			"Taal",
			"Aluf"
			};
                return nagad[r.Next(nagad.Count)];
            }
        }

        public string RandomKeva_en()
        {
            var a = new List<string>{
			"Y",
			"N"
			};
            if (giusdate.Year >= 2016)
            {
                return a[1];
            }
            else
            {
                return a[0];
            }
        }

        public string RandomOrderType_en()
        {
            var a = new List<string>{
			"Weapon",
			"Ammo",
			"Rockets",
			"Tools",
			"Cleaning"
			};

            int index = r.Next(a.Count);
            type = a[index];

            return a[index];
        }

        public string RandomGender_en()
        {
            var a = new List<string>{
			"M",
			"F"
			};

            if (name == "Avigail" || name == "Sharon" || name == "Neomi" || name == "Emma" || name == "Sivan" ||
            name == "Neama" || name == "Tamar" || name == "Maya" || name == "Yael" || name == "Shira")
            {
                return a[1];
            }
            else
            {
                return a[0];
            }
        }

        public string RandomOrderProduct_en()
        {
            var weapons = new List<string>{
			"M4A1",
			"Glock"
			};

            var bullets = new List<string>{
			"556x45",
			"9x19mm",
			"762x39"
			};

            var rockets = new List<string>
			{
			"AGM-88",
			"AIM-120",
			"IRIS-T",
			"AIM-9X"
			};

            var parts = new List<string>{
			"Elen Keys",
			"Screwdriver",
			"Wrench",
			"Welding Torch"
			};

            var cleaning = new List<string>
			{
			"Soap",
			"Sponge",
			"Cleaning Pad",
			"Bleach"
			};

            if (type == "Weapon")
            {
                int index = r.Next(weapons.Count);
                item = weapons[index];
                return weapons[index];
            }
            else if (type == "Ammo")
            {
                int index = r.Next(bullets.Count);
                item = bullets[index];
                return bullets[index];
            }

            else if (type == "Rockets")
            {
                int index = r.Next(rockets.Count);
                item = rockets[index];
                return rockets[index];
            }

            else if (type == "Tools")
            {
                int index = r.Next(parts.Count);
                item = parts[index];
                return parts[index];
            }

            else if (type == "Cleaning")
            {
                int index = r.Next(cleaning.Count);
                item = cleaning[index];
                return cleaning[index];
            }

            return default;
        }

        public int RandomOrderQuantity_en()
        {

            if (item == "M4A1")
            {
                a = r.Next(10, 70);

                return a;
            }

            else if (item == "Glock")
            {
                a = r.Next(15, 125);

                return a;
            }

            else if (type == "Tools")
            {
                a = r.Next(5, 20);

                return a;
            }

            else if (type == "Cleaning")
            {
                a = r.Next(25, 500);

                return a;
            }

            else if (type == "Rockets")
            {
                a = r.Next(10, 350);

                return a;
            }

            else
            {
                a = r.Next(15, 500);
                return a;
            }

        }

        public int RandomOrderPricePerUnit_en()
        {
            if (type == "Ammo")
            {
                b = r.Next(45, 200);

                return b;
            }
            else if (type == "Tools")
            {
                b = r.Next(100, 500);
                return b;
            }
            else if (item == "Sponge")
            {
                b = 5;
                return b;
            }
            else if (item == "Bleach")
            {
                b = 25;
                return b;
            }
            else if (item == "Soap")
            {
                b = 12;
                return b;
            }
            else if (item == "Cleaning Pad")
            {
                b = 10;
                return b;
            }
            else if (item == "M4A1")
            {
                b = 4700;

                return b;
            }
            else if (item == "Glock")
            {
                b = 2200;

                return b;
            }
            else
            {
                b = r.Next(2800, 12000);
                return b;
            }
        }
		
    }
}