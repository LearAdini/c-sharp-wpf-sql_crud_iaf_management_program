﻿using System;
using System.Net;
using System.Net.Sockets;

namespace MidtermProject.Utilities
{
   public class IpCheck
    {
        public  string _IP { get; set; }

        public IpCheck()
        {        
            _IP = GetLocalIPAddress();
        }
        
        public static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    //Console.WriteLine(ip.ToString());
                    return ip.ToString();
                }
            }
            throw new Exception("No network adapters with an internet protocol address in the system!");
        }
    }
}
