﻿// Paste this in a new project if you want to see how each birthdate year is assigned to be 18 years less then the recruit year 
/*
using System;

namespace AssignBirthDateConsole
{
   internal class AssignBirthDateConsoleTest
    {
        public Random r = new Random();
        public static DateTime giusdate;

        static void Main(string[] args)
        {
            for (int i = 0; i < 500; i++)
            {
                Console.WriteLine("---------------");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Recruit Date: ");
                Console.WriteLine(RandomGiusDay());
                System.Threading.Thread.Sleep(20);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("DOB: ");
                Console.WriteLine(RandomBirthDay());
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("---------------");
            }
        }


        public static DateTime RandomGiusDay()
        {
            Random r = new Random();

            DateTime start = new DateTime(2009, 1, 1);
            DateTime end = new DateTime(2018, 12, 31);
            int range = (end - start).Days;
            giusdate = start.AddDays(r.Next(range)).AddHours(r.Next(7, 10)).AddMinutes(r.Next(5, 31));
            return giusdate;
        }

        public static int random_except_list(int n, int[] x)
        {
            int result = x.Length;

            for (int i = 0; i < x.Length; i++)
            {
                if (result < x[i])
                    return result;
                result++;
            }
            if (result == 0)
            {
                result += 1;
            }
            return result; /// for example give n the value of 12 and exclude 2 ,4 ,6 ,9 ,11: random_except_list(12, new int[] { 2, 4, 6, 9, 11 }) will return one of this values: 1, 3, 5, 7, 8, 10, 12
        }

        public static DateTime RandomBirthDay()
        {
            Random r = new Random();
            var date = new DateTime();

            if (giusdate.Year == 2009) // For each year in range (2009 <= 2018) the soldier's birth date will be 18 years less then the recruit date
            {
                date = new DateTime(1991, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;
            }

            else if (giusdate.Year == 2010)
            {
                date = new DateTime(1992, r.Next(1, 13), r.Next(1, 30)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61)); // Leap Year
                return date;
            }

            else if (giusdate.Year == 2011)
            {
                date = new DateTime(1993, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;
            }

            else if (giusdate.Year == 2012)
            {
                date = new DateTime(1994, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;
            }

            else if (giusdate.Year == 2013)
            {
                date = new DateTime(1995, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;

            }

            else if (giusdate.Year == 2014)
            {
                date = new DateTime(1996, r.Next(1, 13), r.Next(1, 30)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));// Leap Year
                return date;

            }

            else if (giusdate.Year == 2015)
            {
                date = new DateTime(1997, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;

            }

            else if (giusdate.Year == 2016)
            {
                date = new DateTime(1998, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;

            }

            else if (giusdate.Year == 2017)
            {
                date = new DateTime(1999, r.Next(1, 13), r.Next(1, 29)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61));
                return date;

            }

            else if (giusdate.Year == 2018)
            {
                date = new DateTime(2000, r.Next(1, 13), r.Next(1, 30)).AddHours(r.Next(1, 25)).AddMinutes(r.Next(1, 61)); // Leap Year
                return date;

            }


            return default;
        }

    }
}
*/